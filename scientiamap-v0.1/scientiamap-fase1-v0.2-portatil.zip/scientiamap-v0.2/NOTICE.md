# Avisos de terceiros

O núcleo do ScientiaMap usa apenas a biblioteca padrão do Python e SQLite. Os
recursos documentais opcionais usam `python-docx`, `openpyxl`, `pypdf` e
`reportlab`, cada qual sob sua própria licença livre. A descoberta bibliográfica
consulta interfaces públicas de Crossref, Europe PMC e arXiv e deve respeitar as
políticas e limites vigentes de cada serviço.

ScientiaMap não é afiliado nem endossado por essas organizações. O programa não
contorna paywalls e não promete busca exaustiva.
