# Arquitetura da Fase 1

## Fluxo principal

```text
Interface PWA -> API local -> validação de domínio -> SQLite
             -> extrator -> mapeador determinístico
             -> busca federada -> cache local
             -> exportador -> JSON/MD/HTML/CSV/TEX/DOCX/XLSX/PDF
```

O navegador continua guardando uma cópia de recuperação, mas o SQLite é a fonte
local versionada. A interface usa uma fila serial de autosave e envia a versão que
leu. Uma resposta 409 impede *last writer wins* silencioso.

## Entidades persistidas

- `projects`: estado corrente normalizado e número da versão.
- `project_versions`: snapshot integral a cada alteração material.
- `stage_revisions`: conteúdo e SHA-256 das etapas alteradas.
- `audit_events`: tipo, resumo, caminhos alterados, autor local e data.
- `documents`: texto extraído, hash, metadados e avisos; não guarda o binário.
- `search_cache`: reservado no schema para evolução; o serviço 0.2 usa arquivos
  JSON atômicos por consulta no diretório de cache.

## Decisões

1. **Biblioteca padrão no núcleo.** Mantém início simples no Windows e reduz a
   superfície de dependências. Pacotes livres são carregados sob demanda para
   formatos documentais.
2. **Snapshots integrais.** Na escala pessoal, tornam restauração e auditoria mais
   fáceis de verificar que deltas encadeados. Revisões por etapa reduzem a perda de
   proveniência metodológica.
3. **Sem exclusão HTTP.** Arquivar é reversível no banco; uma política posterior
   poderá tratar retenção e eliminação explícitas.
4. **Analisador determinístico.** Resultados reproduzíveis, explicáveis por termos
   e trechos. Modelos locais semânticos ficam para uma fase posterior e nunca
   devem apagar os avisos epistemológicos.
5. **Fontes federadas isoladas.** Uma base indisponível não derruba as demais. A
   resposta declara erros e não finge exaustividade.
6. **PWA shell offline.** A interface pode abrir sem rede externa; persistência
   versionada ainda requer o processo Python local.

## Fronteiras de confiança

- Entrada de projeto é normalizada; campos desconhecidos são descartados.
- Arquivos têm limites de bytes, páginas, células e tamanho descomprimido.
- HTML extraído ignora `script`, `style` e `template`; a interface escapa conteúdo
  dinâmico antes de inseri-lo.
- URLs exibidas são limitadas a HTTP/HTTPS.
- Escritas verificam origem quando o navegador envia `Origin`.
- O servidor padrão é `127.0.0.1`; esta arquitetura não autoriza exposição pública.

## Próxima fronteira técnica

A Fase 2 deve separar rubricas por desenho de estudo, implementar importação de
citações, expandir fontes abertas, acrescentar OCR opcional e criar uma camada de
plugins locais. Antes de colaboração em rede, são necessários identidade,
permissões, criptografia em trânsito, proteção contra CSRF robusta, política de
retenção e testes de ameaça.
