# API local do ScientiaMap 0.2

Base padrão: `http://127.0.0.1:8765`. Todas as escritas exigem
`Content-Type: application/json`. A versão do projeto é um inteiro monotônico e
deve ser enviada como `expectedVersion` em alterações destrutíveis do estado
corrente. Conflitos retornam HTTP 409 com a versão atual completa.

## Descoberta e saúde

| Método | Caminho | Resultado |
|---|---|---|
| GET | `/api/health` | versão, migração, contagem local e capacidades opcionais |
| GET | `/api/openapi.json` | descrição OpenAPI 3.1 |
| GET | `/api/schema/project-v2.json` | JSON Schema do envelope exportado |

## Projetos e proveniência

| Método | Caminho | Resultado |
|---|---|---|
| GET | `/api/projects` | projetos não arquivados |
| GET | `/api/projects?archived=true` | inclui arquivados |
| POST | `/api/projects` | cria projeto e versão 1 |
| POST | `/api/projects/import` | aceita projeto nu 0.1 ou envelope 1/2 |
| GET | `/api/projects/{id}` | estado corrente completo |
| PUT | `/api/projects/{id}` | atualiza com `expectedVersion` |
| GET | `/api/projects/{id}/versions` | metadados dos snapshots |
| GET | `/api/projects/{id}/audit` | eventos imutáveis de auditoria |
| POST | `/api/projects/{id}/restore` | restaura snapshot como versão nova |
| POST | `/api/projects/{id}/archive` | arquiva sem apagar histórico |
| GET | `/api/projects/{id}/export?format=json` | exporta; formatos: `json`, `md`, `html`, `csv`, `tex`, `docx`, `xlsx`, `pdf` |
| GET | `/api/backup` | cópia consistente do SQLite |

Criação mínima:

```json
{
  "lang": "pt-BR",
  "sourceSchema": "scientiamap-project/v2",
  "reason": "project-created",
  "project": {
    "title": "",
    "question": "",
    "type": "generic",
    "current": 1,
    "updatedAt": "2026-08-13T12:00:00Z",
    "stages": {
      "1": {"main":"","evidence":"","limits":"","checks":[false,false,false],"status":"open","overrideReason":""}
    }
  }
}
```

No corpo real, `stages` contém obrigatoriamente as chaves `1` a `12`. Use o JSON
Schema para o contrato integral.

Atualização:

```json
{
  "project": {"...": "projeto completo"},
  "lang": "pt-BR",
  "expectedVersion": 7,
  "reason": "browser-autosave"
}
```

Conflito:

```json
{
  "error": "version-conflict",
  "message": "versão do projeto mudou desde a última leitura",
  "current": {"id":"prj_...","version":8,"project":{}}
}
```

Restauração:

```json
{"targetVersion": 3, "expectedVersion": 8}
```

## Análise e documentos

| Método | Caminho | Entrada |
|---|---|---|
| POST | `/api/analyze` | `text`, `lang` |
| POST | `/api/documents/extract` | `filename`, `mediaType`, `dataBase64`, `projectId?`, `lang`, `analyze` |

O analisador devolve 12 registros com `confidence`, `status`, `matchedTerms` e
`evidenceSpans`. Os offsets são relativos ao texto submetido. Confiança representa
correspondência textual, não probabilidade de verdade.

Limites atuais: corpo JSON 36 MiB; arquivo decodificado 25 MiB; arquivo Office
descomprimido 120 MiB; 600 páginas PDF; texto extraído 5 milhões de caracteres.

## Busca

`GET /api/search?q=gravidade&from=2010&to=2026`

O resultado consolida Crossref, Europe PMC e arXiv, informa falhas por fonte,
deduplica por DOI/título e usa cache por 24 horas. `refresh=true` ignora o cache.
O serviço aplica intervalo mínimo serializado ao arXiv. Configure opcionalmente
`SCIENTIAMAP_CONTACT_EMAIL` para a etiqueta de contato do Crossref.

## Respostas e segurança

- 400: validação, documento ou formato inválido.
- 403: escrita cross-origin rejeitada.
- 404: projeto, versão ou endpoint inexistente.
- 405: exclusão destrutiva desativada.
- 409: conflito otimista de versão.
- 500: erro local inesperado, sem traceback na resposta.

A API é para um único usuário em loopback. Os cabeçalhos incluem CSP, bloqueio de
frames, `nosniff`, política de referência e restrição de recursos same-origin.
