# ScientiaMap 0.2 — Fase 1

ScientiaMap transforma uma dúvida em um mapa metodológico de 12 etapas e também
decompõe artigos e documentos nesse mesmo framework. Esta versão substitui o
armazenamento exclusivo do navegador por um núcleo local, versionado e auditável
em SQLite, sem API paga e sem enviar projetos a um serviço proprietário.

> **Limite epistemológico:** “pronta” significa que a documentação mínima de uma
> etapa foi preenchida. Não significa que a hipótese é verdadeira, que o desenho
> é ético, que a estatística está correta ou que o estudo foi certificado.

## Começar no Windows

1. Extraia todo o arquivo ZIP para uma pasta comum. Não execute de dentro do ZIP.
2. Tenha Python 3.11 ou mais recente instalado.
3. Dê dois cliques em `INICIAR_WINDOWS.bat`.
4. O navegador abrirá em `http://127.0.0.1:8765/`.
5. Mantenha a janela preta aberta enquanto estiver usando o programa.

O modo básico inclui projetos, SQLite, versões, histórico, análise de texto,
JSON/Markdown/HTML/CSV/LaTeX e busca bibliográfica. Para ler e gerar PDF, Word e
Excel, execute uma vez `INSTALAR_RECURSOS_COMPLETOS_WINDOWS.bat`; o instalador
cria `.venv` dentro da pasta e instala somente pacotes livres com versões fixadas.

Se o Windows exibir um aviso ao abrir um `.bat`, escolha executar somente se o ZIP
foi obtido da fonte em que você confia. Os scripts são texto legível e podem ser
abertos no Bloco de Notas antes da execução.

## Linux e macOS

No terminal, dentro da pasta:

```bash
chmod +x INICIAR_LINUX_MAC.command INSTALAR_RECURSOS_COMPLETOS_LINUX_MAC.command
./INICIAR_LINUX_MAC.command
```

Para os formatos documentais completos, execute primeiro
`./INSTALAR_RECURSOS_COMPLETOS_LINUX_MAC.command`.

## O que a Fase 1 entrega

- Um ou vários projetos locais, cada um com 12 etapas e quatro idiomas de
  interface: português brasileiro, inglês, espanhol e chinês simplificado.
- Migração automática do projeto salvo pelo protótipo 0.1 no navegador.
- SQLite em modo WAL, snapshots imutáveis, revisões por etapa e trilha de
  auditoria.
- Controle otimista de versão: uma aba antiga não sobrescreve silenciosamente a
  edição nova. O usuário pode adotar a versão do banco ou guardar sua edição como
  cópia.
- Restauração não destrutiva: um snapshot antigo vira uma nova versão.
- Leitura de TXT, Markdown, HTML, JSON, CSV e LaTeX; com os recursos opcionais,
  também PDF, DOCX e XLSX.
- Mapeamento determinístico de trechos às 12 etapas, com confiança textual,
  termos encontrados, offsets e avisos explícitos.
- Busca federada em Crossref, Europe PMC e arXiv, com cache local, deduplicação e
  falha isolada por fonte.
- Exportação real para JSON, Markdown, HTML, CSV, LaTeX, DOCX, XLSX e PDF.
- PWA instalável e shell offline. Operações que dependem do servidor local ou da
  internet continuam a declarar essa dependência.
- Backup consistente do banco pelo botão “Backup SQLite” e backup automático
  diário ao iniciar.

## Dados, privacidade e cópias de segurança

Por padrão, os dados ficam em `data/scientiamap.sqlite3`. Anexos não são enviados
para nuvem: o texto extraído, o hash SHA-256 e os metadados são guardados no banco
local. O conteúdo binário original não é mantido nesta fase.

Faça periodicamente três tipos de cópia:

1. Clique em **Backup SQLite** para preservar projetos, versões, auditoria e
   extrações.
2. Exporte projetos críticos como **JSON**, que é o formato portátil e
   reimportável.
3. Copie a pasta completa para outra unidade enquanto o servidor estiver
   encerrado.

Não publique `data/` em repositórios. Ela pode conter perguntas, rascunhos e dados
de pesquisa sensíveis. Esta versão é para um único usuário local e não implementa
autenticação, autorização por equipe nem criptografia de banco.

## Como usar

### Construir um estudo

Comece pela dúvida e documente cada etapa. A etapa seguinte é liberada quando os
campos mínimos e os três critérios ficam completos. “Avançar com ressalva” exige
uma justificativa e deixa essa decisão visível no histórico.

### Analisar um artigo

Cole o texto ou carregue um arquivo. O resultado mostra correspondências, não uma
avaliação automática da validade do artigo. “Não localizado” pode significar
omissão, suplemento separado, extração imperfeita, vocabulário diferente ou
inaplicabilidade.

PDFs baseados apenas em imagem recebem aviso de possível necessidade de OCR; OCR
não faz parte da Fase 1. Planilhas são convertidas em uma representação textual
por aba e célula. Fórmulas são lidas como fórmulas, não recalculadas pelo extrator.

### Buscar literatura

A busca requer internet, não usa chave paga e não contorna paywalls. A lista serve
para descoberta. Uma revisão sistemática precisa de protocolo próprio, múltiplas
bases, estratégias reproduzíveis, triagem e documentação de cobertura.

### Histórico

Cada alteração material produz uma versão. O histórico mostra snapshots e eventos
de auditoria. Restaurar a versão 3 quando a atual é a 8 cria a versão 9; as versões
4–8 continuam preservadas.

## API local

O contrato legível por máquina fica em `/api/openapi.json`; o JSON Schema público,
em `/api/schema/project-v2.json`. A API aceita somente JSON nas escritas, rejeita
origens diferentes, limita tamanho de corpo e desativa `DELETE`. Consulte
[`docs/API.md`](docs/API.md) para os endpoints e exemplos.

## Executar os testes

Com os recursos completos instalados:

```bash
python -m unittest discover -s tests -v
```

No Windows, também é possível executar `EXECUTAR_TESTES.bat`. Os testes cobrem
modelo, migração, SQLite, conflito, restauração, API, cabeçalhos de segurança,
analisador, documentos, formatos de exportação, busca, PWA e estrutura HTML.

## Estrutura

```text
scientiamap-v0.2/
├── run.py                         servidor local
├── scientiamap/                  domínio, banco, API e serviços
│   └── migrations/               migrações SQL ordenadas
├── schemas/                      contrato JSON público
├── web/                          interface PWA sem dependência remota
├── tests/                        testes automatizados
├── docs/                         API, validação e arquitetura
└── data/                         criado no primeiro uso; não distribuir
```

## Limitações conhecidas

- O mapeamento de artigos é heurístico e determinístico; não é um revisor por
  pares, detector geral de vieses ou sistema de prova.
- Não há OCR, gerenciador de citações, resolução semântica por modelo local,
  colaboração em tempo real nem controle de acesso.
- A descoberta bibliográfica ainda não inclui todas as fontes planejadas e nunca
  pode prometer “todos os estudos”.
- A PWA guarda o shell offline, mas a API depende do processo Python local e a
  busca depende das fontes externas.
- PDF em chinês requer uma fonte TrueType compatível disponível no sistema; se
  ela não existir, prefira DOCX ou HTML.
- O servidor deve permanecer em `127.0.0.1`. Expor `--host 0.0.0.0` cria riscos e
  não transforma esta versão em um serviço multiusuário seguro.

## Desenvolvimento e licença

O núcleo usa apenas a biblioteca padrão do Python. Dependências documentais são
opcionais e fixadas em `requirements-optional.txt`. O código é disponibilizado sob
AGPL-3.0-or-later; veja `LICENSE.txt`. Conectores e bibliotecas de terceiros mantêm
suas próprias licenças e políticas.
