@echo off
setlocal
cd /d "%~dp0"
title ScientiaMap 0.2 - instalador de recursos completos

where py >nul 2>nul
if errorlevel 1 goto :python_missing

if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente Python isolado...
  py -3 -m venv ".venv"
  if errorlevel 1 goto :failed
)

echo Instalando leitores e geradores livres de PDF, Word e Excel...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --requirement requirements-optional.txt
if errorlevel 1 goto :failed

echo.
echo Instalacao concluida. Abrindo o ScientiaMap completo...
".venv\Scripts\python.exe" run.py --data-dir "%~dp0data"
exit /b %errorlevel%

:python_missing
echo Python 3.11 ou superior nao foi encontrado.
echo Instale gratuitamente em https://www.python.org/downloads/windows/
pause
exit /b 2

:failed
echo.
echo A instalacao nao foi concluida. Verifique sua conexao e consulte README.md.
echo O modo basico continua disponivel em INICIAR_WINDOWS.bat.
pause
exit /b 1
