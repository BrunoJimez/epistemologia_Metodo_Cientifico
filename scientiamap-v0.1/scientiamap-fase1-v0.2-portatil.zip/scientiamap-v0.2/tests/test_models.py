import unittest

from scientiamap.models import ValidationError, empty_project, normalize_project, unwrap_import


class ProjectModelTests(unittest.TestCase):
    def test_empty_project_has_twelve_stages(self):
        project = empty_project()
        self.assertEqual(list(project["stages"]), [str(index) for index in range(1, 13)])
        self.assertEqual(project["current"], 1)

    def test_v01_envelope_migrates_and_unknown_fields_are_removed(self):
        legacy = empty_project()
        legacy["title"] = "Experimento do pêndulo"
        legacy["unknown"] = "must not survive"
        project, source = unwrap_import({"schema": "scientiamap-project/v1", "lang": "pt-BR", "project": legacy})
        self.assertEqual(source, "scientiamap-project/v1")
        self.assertEqual(project["title"], "Experimento do pêndulo")
        self.assertNotIn("unknown", project)

    def test_override_requires_a_reason(self):
        project = empty_project()
        project["stages"]["1"]["status"] = "override"
        project["stages"]["1"]["overrideReason"] = "curta"
        with self.assertRaises(ValidationError) as context:
            normalize_project(project)
        self.assertEqual(context.exception.path, "$.stages.1.overrideReason")

    def test_rejects_malformed_checks_and_status(self):
        project = empty_project()
        project["stages"]["2"]["checks"] = [True]
        with self.assertRaises(ValidationError):
            normalize_project(project)
        project = empty_project()
        project["stages"]["2"]["status"] = "certified"
        with self.assertRaises(ValidationError):
            normalize_project(project)


if __name__ == "__main__":
    unittest.main()
