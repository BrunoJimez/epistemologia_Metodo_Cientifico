import tempfile
import unittest
from pathlib import Path

from scientiamap.models import empty_project
from scientiamap.storage import Database, VersionConflictError


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.database = Database(self.root / "scientiamap.sqlite3")

    def tearDown(self):
        self.temp.cleanup()

    def test_create_update_conflict_restore_archive_and_backup(self):
        project = empty_project()
        project["title"] = "Projeto inicial"
        created = self.database.create_project(project, source_schema="scientiamap-project/v1")
        self.assertEqual(created["version"], 1)
        self.assertEqual(created["sourceSchema"], "scientiamap-project/v1")

        changed = created["project"]
        changed["title"] = "Projeto revisado"
        changed["stages"]["1"]["main"] = "Descrição longa da observação inicial e do fenômeno que motivou a investigação científica."
        updated = self.database.update_project(created["id"], changed, expected_version=1, reason="test-update")
        self.assertEqual(updated["version"], 2)
        self.assertEqual(updated["project"]["title"], "Projeto revisado")

        with self.assertRaises(VersionConflictError) as context:
            self.database.update_project(created["id"], changed, expected_version=1)
        self.assertEqual(context.exception.current["version"], 2)

        versions = self.database.versions(created["id"])
        self.assertEqual([item["version"] for item in versions], [2, 1])
        events = self.database.audit(created["id"])
        self.assertEqual(events[0]["eventType"], "project.updated")
        self.assertTrue(any(path.startswith("$.stages.1") for path in events[0]["details"]["paths"]))

        restored = self.database.restore(created["id"], 1, expected_version=2)
        self.assertEqual(restored["version"], 3)
        self.assertEqual(restored["project"]["title"], "Projeto inicial")
        self.assertEqual(self.database.versions(created["id"])[0]["reason"], "restored-from-v1")

        backup = self.database.backup(self.root / "backup" / "copy.sqlite3")
        self.assertGreater(backup.stat().st_size, 0)
        copied = Database(backup)
        self.assertEqual(copied.get_project(created["id"])["version"], 3)

        archived = self.database.archive(created["id"], expected_version=3)
        self.assertTrue(archived["archived"])
        self.assertEqual(self.database.list_projects(), [])
        self.assertEqual(len(self.database.list_projects(include_archived=True)), 1)

    def test_noop_update_does_not_create_version(self):
        created = self.database.create_project(empty_project())
        result = self.database.update_project(created["id"], created["project"], expected_version=1)
        self.assertEqual(result["version"], 1)
        self.assertEqual(len(self.database.versions(created["id"])), 1)


if __name__ == "__main__":
    unittest.main()
