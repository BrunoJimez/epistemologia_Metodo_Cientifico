import unittest

from scientiamap.analyzer import analyze_article


ARTICLE = """
Introdução. Observamos um problema de queda e definimos a pergunta de pesquisa e o objetivo.

A literatura anterior motivou a hipótese. Cada variável recebeu definição operacional.

Propomos um modelo e um mecanismo com pressupostos explícitos. A equação gera uma previsão esperada a priori.

O método experimental usa protocolo, amostra e instrumento de controle. A coleta de dados e a medição seguem o procedimento descrito.

A análise estatística usa regressão, intervalo de confiança e análise de sensibilidade. Os resultados são discutidos com limitações e conclusão.

Referências, disponibilidade de dados, disponibilidade de código, replicação e revisão por pares são informadas.
"""


class AnalyzerTests(unittest.TestCase):
    def test_maps_content_to_twelve_stages_with_evidence_offsets(self):
        result = analyze_article(ARTICLE, lang="pt-BR")
        self.assertEqual(len(result["stages"]), 12)
        self.assertEqual(result["engineVersion"], "0.2.0")
        self.assertEqual(result["studyType"], "experimental")
        self.assertGreater(result["wordCount"], 50)
        self.assertTrue(all(stage["status"] != "absent" for stage in result["stages"]))
        for stage in result["stages"]:
            for span in stage["evidenceSpans"]:
                self.assertGreaterEqual(span["start"], 0)
                self.assertGreater(span["end"], span["start"])
                self.assertIn(span["snippet"][:30], ARTICLE)

    def test_warning_does_not_claim_scientific_validity(self):
        result = analyze_article("A research question and method are described in enough text for mapping.", lang="en")
        self.assertTrue(any("not scientific quality" in warning for warning in result["warnings"]))


if __name__ == "__main__":
    unittest.main()
