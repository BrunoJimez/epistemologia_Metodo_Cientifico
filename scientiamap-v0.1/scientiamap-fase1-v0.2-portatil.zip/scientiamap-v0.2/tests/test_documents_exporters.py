import io
import tempfile
import unittest
from pathlib import Path

from scientiamap.documents import DocumentError, extract_document
from scientiamap.exporters import export_project
from scientiamap.models import empty_project


def populated_project():
    project = empty_project()
    project["title"] = "Teste de queda livre"
    project["question"] = "Como o tempo de queda varia com a altura?"
    project["type"] = "experimental"
    for index in range(1, 13):
        stage = project["stages"][str(index)]
        stage["main"] = f"Registro principal da etapa {index}, com procedimento, raciocínio e decisões documentadas."
        stage["evidence"] = f"Fonte, observação ou decisão associada à etapa {index}, registrada para auditoria."
        stage["limits"] = f"Limitação e incerteza reconhecidas na etapa {index}."
        stage["checks"] = [True, True, True]
        stage["status"] = "ready"
    return project


class DocumentAndExporterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import docx  # noqa: F401
            import openpyxl  # noqa: F401
            import pypdf  # noqa: F401
            import reportlab  # noqa: F401
        except ImportError as exc:
            raise unittest.SkipTest(f"optional test dependency missing: {exc}")

    def test_extracts_text_html_docx_xlsx_and_pdf(self):
        from docx import Document
        from openpyxl import Workbook
        from reportlab.pdfgen.canvas import Canvas

        text = extract_document("paper.txt", "Método experimental e análise estatística.".encode(), "text/plain")
        self.assertIn("Método experimental", text["text"])

        html = extract_document("paper.html", b"<h1>Title</h1><script>bad()</script><p>Method and result</p>", "text/html")
        self.assertIn("Method and result", html["text"])
        self.assertNotIn("bad()", html["text"])

        document = Document()
        document.add_heading("Research method", 1)
        document.add_paragraph("An experimental procedure and statistical analysis.")
        document.add_table(rows=1, cols=2).rows[0].cells[0].text = "data"
        docx_buffer = io.BytesIO()
        document.save(docx_buffer)
        docx_result = extract_document("paper.docx", docx_buffer.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        self.assertIn("experimental procedure", docx_result["text"])
        self.assertEqual(docx_result["metadata"]["tables"], 1)

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Raw data"
        sheet.append(["height", "time"])
        sheet.append([1.0, 0.45])
        xlsx_buffer = io.BytesIO()
        workbook.save(xlsx_buffer)
        xlsx_result = extract_document("data.xlsx", xlsx_buffer.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.assertIn("[SHEET Raw data]", xlsx_result["text"])
        self.assertIn("height\ttime", xlsx_result["text"])

        pdf_buffer = io.BytesIO()
        canvas = Canvas(pdf_buffer)
        canvas.drawString(72, 760, "Experimental method and results")
        canvas.save()
        pdf_result = extract_document("paper.pdf", pdf_buffer.getvalue(), "application/pdf")
        self.assertIn("Experimental method", pdf_result["text"])
        self.assertEqual(pdf_result["metadata"]["pages"], 1)

    def test_exports_all_claimed_formats_as_real_files(self):
        from docx import Document
        from openpyxl import load_workbook
        from pypdf import PdfReader

        project = populated_project()
        formats = ["json", "md", "html", "csv", "tex", "docx", "xlsx", "pdf"]
        exported = {name: export_project(project, "pt-BR", name) for name in formats}
        self.assertTrue(exported["docx"].body.startswith(b"PK"))
        self.assertTrue(exported["xlsx"].body.startswith(b"PK"))
        self.assertTrue(exported["pdf"].body.startswith(b"%PDF"))
        self.assertTrue(exported["csv"].body.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"scientiamap-project/v2", exported["json"].body)
        self.assertIn(b"<!doctype html>", exported["html"].body)
        self.assertIn(b"\\documentclass", exported["tex"].body)

        doc = Document(io.BytesIO(exported["docx"].body))
        self.assertEqual(doc.core_properties.title, project["title"])
        self.assertGreater(len(doc.paragraphs), 30)
        workbook = load_workbook(io.BytesIO(exported["xlsx"].body), read_only=True)
        self.assertEqual(workbook.sheetnames, ["ScientiaMap", "Metadados"])
        self.assertEqual(workbook["ScientiaMap"].max_row, 13)
        workbook.close()
        reader = PdfReader(io.BytesIO(exported["pdf"].body))
        self.assertGreaterEqual(len(reader.pages), 2)

    def test_rejects_empty_and_oversized_documents(self):
        with self.assertRaises(DocumentError):
            extract_document("empty.txt", b"", "text/plain")
        with self.assertRaises(DocumentError):
            extract_document("huge.txt", b"x" * (25 * 1024 * 1024 + 1), "text/plain")


if __name__ == "__main__":
    unittest.main()
