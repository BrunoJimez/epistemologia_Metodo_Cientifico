import tempfile
import unittest
from pathlib import Path

from scientiamap.search import SearchService


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.service = SearchService(Path(self.temp.name))

    def tearDown(self):
        self.temp.cleanup()

    def test_federation_deduplicates_and_isolates_source_errors(self):
        def first(query, year_from, year_to):
            return [{"id": "a", "title": "Shared study", "authors": ["A"], "year": 2024, "venue": "J", "doi": "10.1/shared", "url": "https://doi.org/10.1/shared", "source": "One", "type": "article", "openAccess": False, "sourceRank": 2}]

        def second(query, year_from, year_to):
            return [{"id": "b", "title": "Shared study", "authors": ["A"], "year": 2024, "venue": "J", "doi": "10.1/shared", "url": "https://example.org/open", "source": "Two", "type": "article", "openAccess": True, "sourceRank": 1}]

        def broken(query, year_from, year_to):
            raise TimeoutError("simulated")

        self.service.sources = {"One": first, "Two": second, "Broken": broken}
        result = self.service.search("gravity")
        self.assertEqual(len(result["results"]), 1)
        self.assertEqual(result["results"][0]["source"], "One + Two")
        self.assertTrue(result["results"][0]["openAccess"])
        self.assertEqual(result["sourceErrors"][0]["source"], "Broken")
        self.assertEqual(self.service.search("gravity")["cache"], "hit")

    def test_rejects_invalid_query_and_year_range(self):
        with self.assertRaises(ValueError):
            self.service.search("x")
        with self.assertRaises(ValueError):
            self.service.search("gravity", 2025, 2020)


if __name__ == "__main__":
    unittest.main()
