"""ScientiaMap automated tests."""
