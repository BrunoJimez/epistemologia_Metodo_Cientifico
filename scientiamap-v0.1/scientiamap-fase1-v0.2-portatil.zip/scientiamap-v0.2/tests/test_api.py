import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

from scientiamap.api import ScientiaHandler
from scientiamap.models import empty_project
from scientiamap.search import SearchService
from scientiamap.storage import Database


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        ScientiaHandler.database = Database(cls.root / "scientiamap.sqlite3")
        ScientiaHandler.search_service = SearchService(cls.root / "cache")
        ScientiaHandler.web_root = Path(__file__).resolve().parents[1] / "web"
        ScientiaHandler.data_dir = cls.root
        ScientiaHandler.debug = True
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), ScientiaHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=3)
        cls.temp.cleanup()

    def request(self, path, method="GET", payload=None, expected=200):
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"} if body is not None else {}
        request = urllib.request.Request(self.base + path, data=body, method=method, headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=10)
        except urllib.error.HTTPError as error:
            response = error
        self.assertEqual(response.status, expected)
        data = response.read()
        if "application/json" in (response.headers.get("Content-Type") or "") and not response.headers.get("Content-Disposition"):
            return json.loads(data)
        return data, response.headers

    def test_health_schema_crud_conflict_history_export_and_backup(self):
        health = self.request("/api/health")
        self.assertEqual(health["status"], "ok")
        self.assertEqual(health["database"]["migration"], 1)
        schema = self.request("/api/schema/project-v2.json")
        self.assertEqual(schema["title"], "ScientiaMap Project v2")

        project = empty_project()
        project["title"] = "API project"
        created = self.request("/api/projects", "POST", {"project": project, "lang": "en"}, 201)
        project_id = created["id"]
        self.assertEqual(created["version"], 1)

        project = created["project"]
        project["question"] = "How does height affect free-fall time?"
        updated = self.request(f"/api/projects/{project_id}", "PUT", {"project": project, "lang": "en", "expectedVersion": 1})
        self.assertEqual(updated["version"], 2)
        conflict = self.request(f"/api/projects/{project_id}", "PUT", {"project": project, "expectedVersion": 1}, 409)
        self.assertEqual(conflict["current"]["version"], 2)
        self.assertEqual(len(self.request(f"/api/projects/{project_id}/versions")["versions"]), 2)
        self.assertGreaterEqual(len(self.request(f"/api/projects/{project_id}/audit")["events"]), 2)

        body, headers = self.request(f"/api/projects/{project_id}/export?format=json")
        self.assertIn(b"scientiamap-project/v2", body)
        self.assertIn("attachment", headers["Content-Disposition"])
        backup, _ = self.request("/api/backup")
        self.assertTrue(backup.startswith(b"SQLite format 3"))

    def test_import_analyze_document_and_security_headers(self):
        legacy = empty_project()
        legacy["title"] = "Migrated"
        imported = self.request("/api/projects/import", "POST", {"payload": {"schema": "scientiamap-project/v1", "project": legacy}}, 201)
        self.assertEqual(imported["sourceSchema"], "scientiamap-project/v1")
        analysis = self.request("/api/analyze", "POST", {"text": "A research question, hypothesis, method, data collection, analysis, results, limitations and references are documented.", "lang": "en"})
        self.assertEqual(len(analysis["stages"]), 12)

        encoded = "TWV0aG9kIGV4cGVyaW1lbnRhbCBhbmQgcmVzdWx0cy4="
        extracted = self.request("/api/documents/extract", "POST", {"filename": "paper.txt", "mediaType": "text/plain", "dataBase64": encoded, "analyze": True, "lang": "en"})
        self.assertIn("Method experimental", extracted["text"])
        self.assertIn("document", extracted)

        response = urllib.request.urlopen(self.base + "/", timeout=10)
        self.assertEqual(response.headers["X-Frame-Options"], "DENY")
        self.assertIn("object-src 'none'", response.headers["Content-Security-Policy"])

    def test_delete_is_disabled_and_cross_origin_write_is_rejected(self):
        request = urllib.request.Request(self.base + "/api/projects/prj_" + "0" * 32, method="DELETE")
        with self.assertRaises(urllib.error.HTTPError) as context:
            urllib.request.urlopen(request, timeout=10)
        self.assertEqual(context.exception.code, 405)

        payload = json.dumps({"project": empty_project()}).encode()
        request = urllib.request.Request(self.base + "/api/projects", data=payload, method="POST", headers={"Content-Type": "application/json", "Origin": "https://evil.example"})
        with self.assertRaises(urllib.error.HTTPError) as context:
            urllib.request.urlopen(request, timeout=10)
        self.assertEqual(context.exception.code, 403)


if __name__ == "__main__":
    unittest.main()
