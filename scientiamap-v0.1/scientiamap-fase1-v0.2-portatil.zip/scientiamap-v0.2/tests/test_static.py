import json
import re
import unittest
from html.parser import HTMLParser
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "web"


class StructureParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.label_fors = []
        self.assets = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get("id"):
            self.ids.append(values["id"])
        if tag == "label" and values.get("for"):
            self.label_fors.append(values["for"])
        if tag == "script" and values.get("src"):
            self.assets.append(values["src"])
        if tag == "link" and values.get("href") and values.get("rel") in {"stylesheet", "manifest", "icon"}:
            self.assets.append(values["href"])


class StaticInterfaceTests(unittest.TestCase):
    def test_html_ids_labels_and_assets(self):
        parser = StructureParser()
        parser.feed((WEB / "index.html").read_text(encoding="utf-8"))
        self.assertEqual(len(parser.ids), len(set(parser.ids)), "duplicate HTML IDs")
        self.assertTrue(set(parser.label_fors).issubset(set(parser.ids)), "label points to a missing control")
        for asset in parser.assets:
            self.assertTrue((WEB / asset.lstrip("/")).exists(), asset)

    def test_manifest_and_service_worker_shell_are_complete(self):
        manifest = json.loads((WEB / "manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertEqual(manifest["display"], "standalone")
        for icon in manifest["icons"]:
            self.assertTrue((WEB / icon["src"].lstrip("/")).exists())
        worker = (WEB / "service-worker.js").read_text(encoding="utf-8")
        shell_match = re.search(r"const SHELL = \[(.*?)\];", worker)
        self.assertIsNotNone(shell_match)
        for asset in re.findall(r'"([^"]+)"', shell_match.group(1)):
            if asset != "/":
                self.assertTrue((WEB / asset.lstrip("/")).exists(), asset)
        self.assertIn('url.pathname.startsWith("/api/")', worker)

    def test_javascript_uses_no_remote_runtime_or_paid_api(self):
        scripts = "\n".join(path.read_text(encoding="utf-8") for path in (WEB / "app.js", WEB / "v2.js"))
        self.assertNotRegex(scripts, r"(?:fetch|import)\(\s*['\"]https?://")
        self.assertNotIn("eval(", scripts)
        self.assertNotRegex(scripts, r"innerHTML\s*=\s*event(?:\.|\[)")


if __name__ == "__main__":
    unittest.main()
