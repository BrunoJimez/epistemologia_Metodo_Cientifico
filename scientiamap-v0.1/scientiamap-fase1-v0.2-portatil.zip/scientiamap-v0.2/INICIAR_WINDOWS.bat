@echo off
setlocal
cd /d "%~dp0"
title ScientiaMap 0.2

if exist ".venv\Scripts\python.exe" goto :use_venv
where py >nul 2>nul
if not errorlevel 1 goto :use_py
where python >nul 2>nul
if errorlevel 1 goto :python_missing
set "SCIENTIAMAP_PY=python"
goto :run

:use_venv
set "SCIENTIAMAP_PY=.venv\Scripts\python.exe"
goto :run

:use_py
set "SCIENTIAMAP_PY=py -3"

:run

echo.
echo ScientiaMap 0.2 - iniciando em modo local...
echo Seus dados ficarao na pasta data ao lado deste arquivo.
echo.
%SCIENTIAMAP_PY% run.py --data-dir "%~dp0data"
if errorlevel 1 (
  echo.
  echo O ScientiaMap encontrou um erro. Consulte README.md.
  pause
)
exit /b %errorlevel%

:python_missing
echo.
echo Python 3.11 ou superior nao foi encontrado.
echo Instale gratuitamente em https://www.python.org/downloads/windows/
echo Durante a instalacao, marque "Add Python to PATH".
echo.
pause
exit /b 2
