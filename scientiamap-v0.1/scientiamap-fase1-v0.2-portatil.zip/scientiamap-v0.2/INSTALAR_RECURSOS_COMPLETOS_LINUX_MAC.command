#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"
python3 -m venv .venv
".venv/bin/python" -m pip install --disable-pip-version-check --requirement requirements-optional.txt
exec ".venv/bin/python" run.py --data-dir "$SCRIPT_DIR/data"
