from __future__ import annotations

import base64
import json
import mimetypes
import re
import traceback
import urllib.parse
from datetime import UTC, datetime
from email.utils import formatdate
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

from . import __version__
from .analyzer import analyze_article
from .documents import DocumentError, extract_document
from .exporters import ExportError, export_project
from .models import SCHEMA_VERSION, ValidationError, empty_project, unwrap_import
from .search import SearchService
from .storage import Database, NotFoundError, VersionConflictError

MAX_JSON_BODY = 36 * 1024 * 1024
PROJECT_ID = r"prj_[0-9a-f]{32}"


def openapi_document() -> dict[str, Any]:
    return {
        "openapi": "3.1.0",
        "info": {"title": "ScientiaMap Local API", "version": __version__, "description": "Local-first research project API. Readiness is documentary completeness, not scientific certification."},
        "servers": [{"url": "/"}],
        "paths": {
            "/api/health": {"get": {"summary": "Runtime and database health"}},
            "/api/projects": {"get": {"summary": "List local projects"}, "post": {"summary": "Create a versioned project"}},
            "/api/projects/{project_id}": {"get": {"summary": "Get project"}, "put": {"summary": "Update with optimistic version guard"}},
            "/api/projects/{project_id}/audit": {"get": {"summary": "Immutable audit events"}},
            "/api/projects/{project_id}/versions": {"get": {"summary": "Project versions"}},
            "/api/projects/{project_id}/restore": {"post": {"summary": "Restore an older snapshot as a new version"}},
            "/api/projects/{project_id}/export": {"get": {"summary": "Export project"}},
            "/api/analyze": {"post": {"summary": "Map article text to the 12-stage framework"}},
            "/api/documents/extract": {"post": {"summary": "Extract text from an uploaded document"}},
            "/api/search": {"get": {"summary": "Federated scholarly metadata search"}},
            "/api/backup": {"get": {"summary": "Download a consistent SQLite backup"}},
        },
        "components": {"schemas": {"ProjectEnvelope": {"$ref": "/api/schema/project-v2.json"}}},
    }


class ScientiaHandler(SimpleHTTPRequestHandler):
    database: Database
    search_service: SearchService
    web_root: Path
    data_dir: Path
    debug = False

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(self.web_root), **kwargs)

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        super().end_headers()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if not parsed.path.startswith("/api/"):
            return super().do_GET()
        try:
            self._handle_get(parsed)
        except Exception as exc:
            self._handle_exception(exc)

    def do_POST(self) -> None:
        try:
            self._require_same_origin()
            self._handle_write("POST")
        except Exception as exc:
            self._handle_exception(exc)

    def do_PUT(self) -> None:
        try:
            self._require_same_origin()
            self._handle_write("PUT")
        except Exception as exc:
            self._handle_exception(exc)

    def do_DELETE(self) -> None:
        self._json_response(HTTPStatus.METHOD_NOT_ALLOWED, {"error": "deletion-disabled", "message": "Use archival; destructive deletion is disabled."})

    def _handle_get(self, parsed: urllib.parse.ParseResult) -> None:
        path = parsed.path.rstrip("/")
        params = urllib.parse.parse_qs(parsed.query)
        if path == "/api/health":
            capabilities = self._capabilities()
            return self._json_response(HTTPStatus.OK, {
                "status": "ok", "version": __version__, "schema": SCHEMA_VERSION,
                "database": self.database.health(), "capabilities": capabilities,
                "warning": "readiness means documentary completeness, not scientific certification",
            })
        if path == "/api/openapi.json":
            return self._json_response(HTTPStatus.OK, openapi_document())
        if path == "/api/schema/project-v2.json":
            schema_path = Path(__file__).resolve().parent.parent / "schemas" / "project-v2.schema.json"
            return self._json_response(HTTPStatus.OK, json.loads(schema_path.read_text(encoding="utf-8")))
        if path == "/api/projects":
            include_archived = (params.get("archived") or [""])[0].casefold() == "true"
            return self._json_response(HTTPStatus.OK, {"projects": self.database.list_projects(include_archived)})
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})", path)
        if match:
            return self._json_response(HTTPStatus.OK, self.database.get_project(match.group(1)))
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})/audit", path)
        if match:
            limit = self._int_param(params, "limit", 200, 1, 1000)
            return self._json_response(HTTPStatus.OK, {"events": self.database.audit(match.group(1), limit)})
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})/versions", path)
        if match:
            limit = self._int_param(params, "limit", 100, 1, 500)
            return self._json_response(HTTPStatus.OK, {"versions": self.database.versions(match.group(1), limit)})
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})/export", path)
        if match:
            project = self.database.get_project(match.group(1))
            format_name = (params.get("format") or ["json"])[0]
            exported = export_project(project["project"], project["lang"], format_name)
            return self._binary_response(exported.body, exported.media_type, exported.filename, exported.warnings)
        if path == "/api/search":
            query = (params.get("q") or [""])[0]
            year_from = self._optional_year(params, "from")
            year_to = self._optional_year(params, "to")
            refresh = (params.get("refresh") or [""])[0].casefold() == "true"
            return self._json_response(HTTPStatus.OK, self.search_service.search(query, year_from, year_to, refresh=refresh))
        if path == "/api/backup":
            stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
            destination = self.data_dir / "backups" / f"scientiamap-backup-{stamp}.sqlite3"
            self.database.backup(destination)
            return self._binary_response(destination.read_bytes(), "application/vnd.sqlite3", destination.name, [])
        self._json_response(HTTPStatus.NOT_FOUND, {"error": "not-found", "message": "Endpoint not found"})

    def _handle_write(self, method: str) -> None:
        path = urllib.parse.urlparse(self.path).path.rstrip("/")
        payload = self._read_json()
        if method == "POST" and path == "/api/projects":
            project = payload.get("project", empty_project())
            created = self.database.create_project(
                project, lang=payload.get("lang", "pt-BR"), source_schema=str(payload.get("sourceSchema", SCHEMA_VERSION)),
                reason=str(payload.get("reason", "project-created")),
            )
            return self._json_response(HTTPStatus.CREATED, created)
        if method == "POST" and path == "/api/projects/import":
            clean, source_schema = unwrap_import(payload.get("payload", payload))
            lang = payload.get("lang") or (payload.get("payload", {}).get("lang") if isinstance(payload.get("payload"), dict) else None) or "pt-BR"
            created = self.database.create_project(clean, lang=lang, source_schema=source_schema, reason="imported-project")
            return self._json_response(HTTPStatus.CREATED, created)
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})", path)
        if method == "PUT" and match:
            updated = self.database.update_project(
                match.group(1), payload.get("project"), expected_version=self._expected_version(payload),
                lang=payload.get("lang"), reason=str(payload.get("reason", "autosave")),
            )
            return self._json_response(HTTPStatus.OK, updated)
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})/restore", path)
        if method == "POST" and match:
            restored = self.database.restore(
                match.group(1), int(payload.get("targetVersion", 0)), expected_version=self._expected_version(payload),
            )
            return self._json_response(HTTPStatus.OK, restored)
        match = re.fullmatch(fr"/api/projects/({PROJECT_ID})/archive", path)
        if method == "POST" and match:
            archived = self.database.archive(match.group(1), expected_version=self._expected_version(payload))
            return self._json_response(HTTPStatus.OK, archived)
        if method == "POST" and path == "/api/analyze":
            text = payload.get("text", "")
            if not isinstance(text, str) or len(text.strip()) < 30:
                raise ValidationError("texto muito curto para análise", "$.text")
            return self._json_response(HTTPStatus.OK, analyze_article(text, lang=payload.get("lang", "pt-BR")))
        if method == "POST" and path == "/api/documents/extract":
            encoded = payload.get("dataBase64", "")
            if not isinstance(encoded, str):
                raise ValidationError("dataBase64 deve ser texto", "$.dataBase64")
            try:
                data = base64.b64decode(encoded, validate=True)
            except Exception as exc:
                raise ValidationError("base64 inválido", "$.dataBase64") from exc
            result = extract_document(str(payload.get("filename", "document")), data, str(payload.get("mediaType", "application/octet-stream")))
            saved = self.database.save_document(
                project_id=payload.get("projectId"), filename=result["filename"], media_type=result["mediaType"],
                sha256=result["sha256"], byte_size=result["byteSize"], extracted_text=result["text"],
                metadata=result["metadata"], warnings=result["warnings"],
            )
            result["document"] = saved
            if payload.get("analyze") and result["text"].strip():
                result["analysis"] = analyze_article(result["text"], lang=payload.get("lang", "pt-BR"))
            return self._json_response(HTTPStatus.OK, result)
        self._json_response(HTTPStatus.NOT_FOUND, {"error": "not-found", "message": "Endpoint not found"})

    def _read_json(self) -> dict[str, Any]:
        content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().casefold()
        if content_type != "application/json":
            raise ValidationError("Content-Type deve ser application/json", "$")
        raw_length = self.headers.get("Content-Length", "")
        if not raw_length.isdigit():
            raise ValidationError("Content-Length ausente ou inválido", "$")
        length = int(raw_length)
        if length > MAX_JSON_BODY:
            raise ValidationError("requisição excede 36 MiB", "$")
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValidationError("JSON inválido", "$") from exc
        if not isinstance(value, dict):
            raise ValidationError("corpo JSON deve ser um objeto", "$")
        return value

    def _require_same_origin(self) -> None:
        origin = self.headers.get("Origin")
        if not origin:
            return
        parsed = urllib.parse.urlparse(origin)
        host = self.headers.get("Host", "")
        if parsed.scheme not in {"http", "https"} or parsed.netloc != host:
            raise PermissionError("cross-origin write rejected")

    def _expected_version(self, payload: dict[str, Any]) -> int:
        value = payload.get("expectedVersion")
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValidationError("expectedVersion deve ser inteiro positivo", "$.expectedVersion")
        return value

    def _optional_year(self, params: dict[str, list[str]], name: str) -> int | None:
        value = (params.get(name) or [""])[0]
        if not value:
            return None
        if not re.fullmatch(r"\d{4}", value):
            raise ValidationError("ano inválido", f"$.{name}")
        return int(value)

    def _int_param(self, params: dict[str, list[str]], name: str, default: int, minimum: int, maximum: int) -> int:
        value = (params.get(name) or [str(default)])[0]
        if not value.isdigit() or not minimum <= int(value) <= maximum:
            raise ValidationError("parâmetro inteiro inválido", f"$.{name}")
        return int(value)

    def _capabilities(self) -> dict[str, bool]:
        capabilities = {}
        for module, key in (("docx", "docx"), ("openpyxl", "xlsx"), ("pypdf", "pdfRead"), ("reportlab", "pdfWrite")):
            try:
                __import__(module)
                capabilities[key] = True
            except ImportError:
                capabilities[key] = False
        return capabilities

    def _json_response(self, status: HTTPStatus | int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(int(status))
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _binary_response(self, body: bytes, media_type: str, filename: str, warnings: list[str]) -> None:
        ascii_name = re.sub(r"[^A-Za-z0-9._-]", "_", filename)
        encoded_name = urllib.parse.quote(filename)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", media_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{encoded_name}")
        self.send_header("Cache-Control", "no-store")
        if warnings:
            self.send_header("X-ScientiaMap-Warnings", str(len(warnings)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_exception(self, exc: Exception) -> None:
        if isinstance(exc, ValidationError):
            return self._json_response(HTTPStatus.BAD_REQUEST, {"error": "validation", **exc.as_dict()})
        if isinstance(exc, (ValueError, DocumentError, ExportError)):
            return self._json_response(HTTPStatus.BAD_REQUEST, {"error": "invalid-request", "message": str(exc)})
        if isinstance(exc, NotFoundError):
            return self._json_response(HTTPStatus.NOT_FOUND, {"error": "not-found", "message": str(exc)})
        if isinstance(exc, VersionConflictError):
            return self._json_response(HTTPStatus.CONFLICT, {"error": "version-conflict", "message": str(exc), "current": exc.current})
        if isinstance(exc, PermissionError):
            return self._json_response(HTTPStatus.FORBIDDEN, {"error": "forbidden", "message": str(exc)})
        if self.debug:
            traceback.print_exc()
        return self._json_response(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "internal", "message": "Unexpected local server error"})

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[ScientiaMap] {self.address_string()} - {fmt % args}")
