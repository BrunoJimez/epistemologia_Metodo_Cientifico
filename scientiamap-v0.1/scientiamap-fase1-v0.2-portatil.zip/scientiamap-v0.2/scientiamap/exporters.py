from __future__ import annotations

import csv
import html
import io
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import SCHEMA_VERSION
from .rubric import labels, titles, warning


class ExportError(RuntimeError):
    pass


@dataclass
class ExportedFile:
    body: bytes
    media_type: str
    filename: str
    warnings: list[str]


def _slug(value: str) -> str:
    clean = re.sub(r"[^\w]+", "-", value.casefold(), flags=re.UNICODE).strip("-")
    return (clean[:70] or "scientiamap-projeto")


def markdown(project: dict[str, Any], lang: str) -> str:
    label, stage_titles = labels(lang), titles(lang)
    lines = [f"# {project.get('title') or 'ScientiaMap'}", "", f"**{label['question']}:** {project.get('question', '')}", ""]
    for index, title in enumerate(stage_titles, start=1):
        stage = project["stages"][str(index)]
        lines.extend([
            f"## {index}. {title}", "", stage["main"], "",
            f"**{label['evidence']}:** {stage['evidence']}", "",
            f"**{label['limits']}:** {stage['limits']}", "",
            f"**{label['status']}:** {stage['status']}", "",
            *(f"- [{'x' if checked else ' '}] {label['checks']} {check_index}" for check_index, checked in enumerate(stage["checks"], start=1)),
            "",
        ])
        if stage.get("overrideReason"):
            lines.extend([f"> **{label['caveat']}:** {stage['overrideReason']}", ""])
    lines.extend(["---", f"**{label['warning']}:** {warning(lang)}", ""])
    return "\n".join(lines)


def html_document(project: dict[str, Any], lang: str) -> str:
    label, stage_titles = labels(lang), titles(lang)
    sections = []
    for index, title in enumerate(stage_titles, start=1):
        stage = project["stages"][str(index)]
        checks = "".join(f"<li>{'☑' if checked else '☐'} {html.escape(label['checks'])} {check_index}</li>" for check_index, checked in enumerate(stage["checks"], start=1))
        caveat = f"<p class='warning'><strong>{html.escape(label['caveat'])}:</strong> {html.escape(stage.get('overrideReason', ''))}</p>" if stage.get("overrideReason") else ""
        sections.append(f"<section><h2>{index}. {html.escape(title)}</h2><p>{html.escape(stage['main']).replace(chr(10), '<br>')}</p><p><strong>{html.escape(label['evidence'])}:</strong> {html.escape(stage['evidence'])}</p><p><strong>{html.escape(label['limits'])}:</strong> {html.escape(stage['limits'])}</p><p><strong>{html.escape(label['status'])}:</strong> {html.escape(stage['status'])}</p><ul>{checks}</ul>{caveat}</section>")
    return f"""<!doctype html><html lang="{html.escape(lang)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>{html.escape(project.get('title') or 'ScientiaMap')}</title><style>body{{font:16px/1.65 system-ui;max-width:920px;margin:40px auto;padding:0 24px;color:#17251f}}h1,h2{{font-family:Georgia,serif;color:#124d3c}}section{{border-top:1px solid #d8ddd8;padding:20px 0}}.warning{{padding:14px;background:#fff2d8;border-left:4px solid #b97018}}</style></head><body><h1>{html.escape(project.get('title') or 'ScientiaMap')}</h1><p><strong>{html.escape(label['question'])}:</strong> {html.escape(project.get('question', ''))}</p>{''.join(sections)}<p class="warning"><strong>{html.escape(label['warning'])}:</strong> {html.escape(warning(lang))}</p></body></html>"""


def latex(project: dict[str, Any], lang: str) -> str:
    def tex(value: Any) -> str:
        return re.sub(r"([#$%&_{}])", r"\\\1", str(value or "")).replace("~", r"\textasciitilde{}").replace("^", r"\textasciicircum{}")
    label, stage_titles = labels(lang), titles(lang)
    sections = []
    for index, title in enumerate(stage_titles, start=1):
        stage = project["stages"][str(index)]
        sections.append(f"\\section{{{index}. {tex(title)}}}\n{tex(stage['main'])}\n\n\\textbf{{{tex(label['evidence'])}:}} {tex(stage['evidence'])}\n\n\\textbf{{{tex(label['limits'])}:}} {tex(stage['limits'])}\n")
    return f"\\documentclass[11pt]{{article}}\n\\usepackage[utf8]{{inputenc}}\n\\usepackage{{geometry}}\n\\geometry{{margin=2.5cm}}\n\\title{{{tex(project.get('title') or 'ScientiaMap')}}}\n\\begin{{document}}\n\\maketitle\n\\textbf{{{tex(label['question'])}:}} {tex(project.get('question',''))}\n\n{''.join(sections)}\n\\end{{document}}\n"


def csv_bytes(project: dict[str, Any], lang: str) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";")
    label = labels(lang)
    writer.writerow(["stage", "title", "main", label["evidence"], label["limits"], label["status"], label["caveat"]])
    for index, title in enumerate(titles(lang), start=1):
        stage = project["stages"][str(index)]
        writer.writerow([index, title, stage["main"], stage["evidence"], stage["limits"], stage["status"], stage.get("overrideReason", "")])
    return ("\ufeff" + output.getvalue()).encode("utf-8")


def docx_bytes(project: dict[str, Any], lang: str) -> bytes:
    try:
        from docx import Document
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:
        raise ExportError("DOCX requer o pacote livre python-docx") from exc
    label = labels(lang)
    document = Document()
    document.settings.odd_and_even_pages_header_footer = False
    section = document.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.bottom_margin = Inches(1)
    section.left_margin = section.right_margin = Inches(1)
    section.header_distance = section.footer_distance = Inches(0.492)
    normal = document.styles["Normal"]
    normal.font.name, normal.font.size = "Calibri", Pt(11)
    normal.font.color.rgb = RGBColor.from_string("17251F")
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for style_name, size, before, after, color in (
        ("Title", 26, 0, 12, "124D3C"),
        ("Heading 1", 16, 18, 10, "124D3C"),
        ("Heading 2", 13, 14, 7, "1F725A"),
        ("Heading 3", 12, 10, 5, "2B5F75"),
    ):
        style = document.styles[style_name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    title_style = document.styles["Title"]
    title_style.font.bold = True
    title_properties = title_style._element.get_or_add_pPr()
    title_border = title_properties.find(qn("w:pBdr"))
    if title_border is not None:
        title_properties.remove(title_border)
    document.core_properties.title = project.get("title") or "ScientiaMap"
    document.core_properties.subject = "ScientiaMap research project"
    document.core_properties.author = "ScientiaMap"

    footer = section.footer.paragraphs[0]
    footer.alignment = 2
    run = footer.add_run("ScientiaMap 0.2  ·  ")
    run.font.size = Pt(8)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    run._r.addnext(field)

    document.add_heading(project.get("title") or "ScientiaMap", 0)
    paragraph = document.add_paragraph()
    paragraph.add_run(f"{label['question']}: ").bold = True
    paragraph.add_run(project.get("question", ""))
    metadata = document.add_paragraph()
    metadata.add_run("Tipo: ").bold = True
    metadata.add_run(project.get("type", "generic"))
    metadata.add_run("   ·   Etapa atual: ").bold = True
    metadata.add_run(str(project.get("current", 1)))
    document.add_paragraph(warning(lang), style="Intense Quote")
    for index, title in enumerate(titles(lang), start=1):
        stage = project["stages"][str(index)]
        block = [document.add_heading(f"{index}. {title}", level=1)]
        main = document.add_paragraph(stage["main"] or "—")
        block.append(main)
        for key in ("evidence", "limits", "status"):
            paragraph = document.add_paragraph()
            paragraph.add_run(f"{label[key]}: ").bold = True
            paragraph.add_run(str(stage[key]) or "—")
            block.append(paragraph)
        checks = document.add_paragraph()
        checks.add_run(f"{label['checks']}: ").bold = True
        checks.add_run("  ".join(f"{'[x]' if value else '[ ]'} {number}" for number, value in enumerate(stage["checks"], start=1)))
        block.append(checks)
        if stage.get("overrideReason"):
            paragraph = document.add_paragraph(style="Intense Quote")
            paragraph.add_run(f"{label['caveat']}: ").bold = True
            paragraph.add_run(stage["overrideReason"])
            block.append(paragraph)
        for paragraph in block:
            paragraph.paragraph_format.keep_together = True
        for paragraph in block[:-1]:
            paragraph.paragraph_format.keep_with_next = True
        if index == 11:
            block[0].paragraph_format.page_break_before = True
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def xlsx_bytes(project: dict[str, Any], lang: str) -> bytes:
    try:
        from openpyxl import Workbook
        from openpyxl.formatting.rule import FormulaRule
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.table import Table, TableStyleInfo
    except ImportError as exc:
        raise ExportError("XLSX requer o pacote livre openpyxl") from exc
    label = labels(lang)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "ScientiaMap"
    headers = ["Etapa", "Título", "Registro principal", label["evidence"], label["limits"], label["status"], label["caveat"]]
    sheet.append(headers)
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="124D3C")
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
    sheet.row_dimensions[1].height = 34
    for index, title in enumerate(titles(lang), start=1):
        stage = project["stages"][str(index)]
        sheet.append([index, title, stage["main"], stage["evidence"], stage["limits"], stage["status"], stage.get("overrideReason", "")])
    widths = [9, 34, 58, 52, 48, 14, 42]
    for column, width in zip("ABCDEFG", widths):
        sheet.column_dimensions[column].width = width
    for row_index, row in enumerate(sheet.iter_rows(), start=1):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        if row_index > 1:
            sheet.row_dimensions[row_index].height = 76
    for cell in sheet[1]:
        cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
    for row_index in range(2, 14):
        sheet[f"A{row_index}"].alignment = Alignment(vertical="top", horizontal="center", wrap_text=True)
        sheet[f"F{row_index}"].alignment = Alignment(vertical="top", horizontal="center", wrap_text=True)
    sheet.freeze_panes = "A2"
    sheet.sheet_view.showGridLines = False
    table = Table(displayName="ScientiaMapStages", ref="A1:G13")
    table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium4", showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    sheet.add_table(table)
    sheet.conditional_formatting.add("F2:F13", FormulaRule(formula=['F2="override"'], fill=PatternFill("solid", fgColor="FFF2D8")))
    sheet.conditional_formatting.add("F2:F13", FormulaRule(formula=['F2="ready"'], fill=PatternFill("solid", fgColor="D9EBE4")))
    sheet.print_title_rows = "1:1"
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    meta = workbook.create_sheet("Metadados")
    meta_rows = [
        ["Campo", "Valor"], ["schema", SCHEMA_VERSION], ["idioma", lang],
        ["título", project.get("title", "")], ["pergunta", project.get("question", "")],
        ["tipo de estudo", project.get("type", "generic")], ["etapa atual", project.get("current", 1)],
        ["aviso", warning(lang)],
    ]
    for row in meta_rows:
        meta.append(row)
    meta.sheet_view.showGridLines = False
    meta.freeze_panes = "A2"
    meta.column_dimensions["A"].width = 24
    meta.column_dimensions["B"].width = 96
    for cell in meta[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="124D3C")
    for row in meta.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for index in range(2, len(meta_rows) + 1):
        meta.row_dimensions[index].height = 30 if index < len(meta_rows) else 54
    meta.auto_filter.ref = f"A1:B{len(meta_rows)}"
    buffer = io.BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def pdf_bytes(project: dict[str, Any], lang: str) -> tuple[bytes, list[str]]:
    try:
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import cm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer
    except ImportError as exc:
        raise ExportError("PDF requer o pacote livre reportlab") from exc
    warnings: list[str] = []
    font_name = "Helvetica"
    candidates = [
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"), Path("C:/Windows/Fonts/msyh.ttc"),
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.suffix.casefold() == ".ttf":
            try:
                pdfmetrics.registerFont(TTFont("ScientiaUnicode", str(candidate)))
                font_name = "ScientiaUnicode"
                break
            except Exception:
                continue
    if font_name == "Helvetica" and lang == "zh-CN":
        warnings.append("fonte chinesa não encontrada; use DOCX/HTML para preservar todos os glifos")
    buffer = io.BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2.2*cm, leftMargin=2.2*cm, topMargin=2.1*cm, bottomMargin=2.1*cm, title=project.get("title") or "ScientiaMap")
    styles = getSampleStyleSheet()
    for style_name in ("Normal", "Title", "Heading1"):
        styles[style_name].fontName = font_name
    styles["Normal"].fontSize = 9.4
    styles["Normal"].leading = 13
    styles["Normal"].spaceAfter = 3
    styles["Title"].fontSize = 23
    styles["Title"].leading = 28
    styles["Title"].textColor = colors.HexColor("#124D3C")
    styles["Title"].spaceAfter = 14
    styles["Heading1"].fontSize = 14
    styles["Heading1"].leading = 18
    styles["Heading1"].textColor = colors.HexColor("#124D3C")
    styles["Heading1"].spaceBefore = 10
    styles["Heading1"].spaceAfter = 5
    styles["Heading1"].keepWithNext = True
    styles.add(ParagraphStyle(name="WarningBox", parent=styles["Normal"], backColor=colors.HexColor("#FFF2D8"), borderColor=colors.HexColor("#B97018"), borderWidth=1, borderPadding=8, leading=15, alignment=TA_LEFT))
    label, story = labels(lang), []
    story.append(Paragraph(html.escape(project.get("title") or "ScientiaMap"), styles["Title"]))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f"<b>{html.escape(label['question'])}:</b> {html.escape(project.get('question',''))}", styles["Normal"]))
    for index, title in enumerate(titles(lang), start=1):
        stage = project["stages"][str(index)]
        stage_story = [
            Spacer(1, 15), Paragraph(f"{index}. {html.escape(title)}", styles["Heading1"]),
            Paragraph(html.escape(stage["main"] or "—").replace("\n", "<br/>"), styles["Normal"]),
            Spacer(1, 5), Paragraph(f"<b>{html.escape(label['evidence'])}:</b> {html.escape(stage['evidence'])}", styles["Normal"]),
            Spacer(1, 5), Paragraph(f"<b>{html.escape(label['limits'])}:</b> {html.escape(stage['limits'])}", styles["Normal"]),
            Spacer(1, 5), Paragraph(f"<b>{html.escape(label['status'])}:</b> {html.escape(stage['status'])}", styles["Normal"]),
            Spacer(1, 5), Paragraph(f"<b>{html.escape(label['checks'])}:</b> {' &nbsp; '.join(('[x]' if value else '[ ]') + ' ' + str(number) for number, value in enumerate(stage['checks'], start=1))}", styles["Normal"]),
        ]
        if stage.get("overrideReason"):
            stage_story.append(Paragraph(f"<b>{html.escape(label['caveat'])}:</b> {html.escape(stage['overrideReason'])}", styles["WarningBox"]))
        story.append(KeepTogether(stage_story))
    story.extend([Spacer(1, 15), Paragraph(f"<b>{html.escape(label['warning'])}:</b> {html.escape(warning(lang))}", styles["WarningBox"])])
    def page_frame(canvas, doc):
        canvas.saveState()
        canvas.setFont(font_name, 7.5)
        canvas.setFillColor(colors.HexColor("#64736C"))
        canvas.drawString(2.2*cm, A4[1] - 1.25*cm, "SCIENTIAMAP  ·  PROJETO DE PESQUISA")
        canvas.drawRightString(A4[0] - 2.2*cm, 1.05*cm, f"ScientiaMap 0.2  ·  {doc.page}")
        canvas.restoreState()

    document.build(story, onFirstPage=page_frame, onLaterPages=page_frame)
    return buffer.getvalue(), warnings


def export_project(project: dict[str, Any], lang: str, format_name: str) -> ExportedFile:
    base = _slug(project.get("title") or "scientiamap-projeto")
    format_name = format_name.casefold()
    if format_name == "json":
        body = json.dumps({"schema": SCHEMA_VERSION, "lang": lang, "project": project}, ensure_ascii=False, indent=2).encode("utf-8")
        return ExportedFile(body, "application/json; charset=utf-8", f"{base}.json", [])
    if format_name in {"md", "markdown"}:
        return ExportedFile(markdown(project, lang).encode("utf-8"), "text/markdown; charset=utf-8", f"{base}.md", [])
    if format_name == "html":
        return ExportedFile(html_document(project, lang).encode("utf-8"), "text/html; charset=utf-8", f"{base}.html", [])
    if format_name == "csv":
        return ExportedFile(csv_bytes(project, lang), "text/csv; charset=utf-8", f"{base}.csv", [])
    if format_name in {"tex", "latex"}:
        return ExportedFile(latex(project, lang).encode("utf-8"), "application/x-tex; charset=utf-8", f"{base}.tex", [])
    if format_name == "docx":
        return ExportedFile(docx_bytes(project, lang), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", f"{base}.docx", [])
    if format_name == "xlsx":
        return ExportedFile(xlsx_bytes(project, lang), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", f"{base}.xlsx", [])
    if format_name == "pdf":
        body, warnings = pdf_bytes(project, lang)
        return ExportedFile(body, "application/pdf", f"{base}.pdf", warnings)
    raise ExportError(f"formato não suportado: {format_name}")
