from __future__ import annotations

import re
from typing import Any

from .rubric import titles

ENGINE = "scientiamap-deterministic-mapper"
ENGINE_VERSION = "0.2.0"

KEYWORDS: dict[int, list[str]] = {
    1: ["background", "context", "phenomen", "problem", "gap", "observ", "introdução", "fenômeno", "problema", "contexto", "antecedentes", "fenómeno", "问题", "现象", "背景"],
    2: ["research question", "objective", "aim", "purpose", "pergunta", "objetivo", "pregunta", "propósito", "研究问题", "目的"],
    3: ["hypoth", "prior work", "literature", "related work", "hipótese", "literatura", "hipótesis", "假设", "文献"],
    4: ["definition", "operational", "construct", "variable", "outcome", "definição", "operacional", "variável", "definición", "操作性", "变量", "结局"],
    5: ["model", "mechanism", "assumption", "boundary condition", "idealization", "modelo", "mecanismo", "pressuposto", "supuesto", "模型", "机制", "假定"],
    6: ["equation", "formula", "algorithm", "simulation", "parameter", "equação", "fórmula", "algoritmo", "simulação", "ecuación", "方程", "公式", "算法", "参数"],
    7: ["predict", "expected", "preregister", "a priori", "previsão", "predição", "esperado", "predicción", "预测", "预期", "预注册"],
    8: ["method", "design", "protocol", "sample", "participant", "instrument", "random", "control", "método", "desenho", "protocolo", "amostra", "diseño", "muestra", "方法", "设计", "样本", "对照"],
    9: ["data collection", "measurement", "procedure", "experiment", "survey", "interview", "coleta", "medição", "procedimento", "experimento", "encuesta", "数据收集", "测量", "程序", "实验"],
    10: ["analysis", "statistic", "confidence interval", "uncertainty", "sensitivity", "regression", "análise", "estatística", "incerteza", "análisis", "estadística", "分析", "统计", "置信区间"],
    11: ["result", "discussion", "interpret", "support", "limitation", "conclusion", "resultado", "discussão", "interpretação", "limitação", "discusión", "结果", "讨论", "解释", "局限", "结论"],
    12: ["reference", "supplement", "data availability", "code availability", "replic", "peer review", "referência", "disponibilidade", "replicação", "referencia", "参考文献", "数据可用性", "复现"],
}


def infer_study_type(text: str) -> tuple[str, list[str]]:
    value = text.casefold()
    patterns = [
        ("systematic", r"systematic review|meta-analysis|revis[aã]o sistem[aá]tica|revisi[oó]n sistem[aá]tica|系统综述|荟萃分析"),
        ("randomized", r"randomi[sz]ed|aleatori[sz]ad|随机(?:对照)?试验"),
        ("qualitative", r"qualitative|focus group|thematic analysis|qualitativ|定性研究|主题分析"),
        ("observational", r"cohort|case-control|cross-sectional|observational|coorte|transversal|observacional|队列|病例对照|横断面"),
        ("theoretical", r"theorem|lemma|mathematical proof|teorema|demonstra[cç][aã]o|定理|引理|数学证明"),
        ("computational", r"simulation|computational model|machine learning|simula[cç][aã]o|modelo computacional|模拟|机器学习"),
        ("experimental", r"experiment|laboratory|intervention|experimento|实验|干预"),
    ]
    for study_type, pattern in patterns:
        match = re.search(pattern, value)
        if match:
            return study_type, [match.group(0)]
    return "generic", []


def _segments(text: str) -> list[dict[str, Any]]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    boundaries = list(re.finditer(r"\n\s*\n|(?<=[.!?。！？])\s+", normalized))
    pieces: list[dict[str, Any]] = []
    start = 0
    for boundary in boundaries + [None]:
        end = boundary.start() if boundary else len(normalized)
        raw = normalized[start:end]
        leading = len(raw) - len(raw.lstrip())
        trailing = len(raw.rstrip())
        content = re.sub(r"<[^>]+>", " ", raw).strip()
        content = re.sub(r"\s+", " ", content)
        if len(content) >= 30:
            pieces.append({"start": start + leading, "end": start + trailing, "text": content[:700]})
        start = boundary.end() if boundary else len(normalized)
    return pieces


def analyze_article(text: str, *, lang: str = "pt-BR") -> dict[str, Any]:
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    if len(text) > 5_000_000:
        raise ValueError("texto excede 5 milhões de caracteres")
    # Keep the original string so evidence offsets always point into the submitted text.
    normalized = text
    lower = normalized.casefold()
    pieces = _segments(normalized)
    stage_titles = titles(lang)
    results = []
    for stage_id, terms in KEYWORDS.items():
        matches = [term for term in terms if term.casefold() in lower]
        evidence = []
        for segment in pieces:
            found = [term for term in terms if term.casefold() in segment["text"].casefold()]
            if found:
                evidence.append({
                    "start": segment["start"], "end": segment["end"],
                    "snippet": segment["text"][:420], "matchedTerms": found[:8],
                })
            if len(evidence) == 3:
                break
        raw = 0 if not matches else 18 + len(matches) * 9 + min(27, len(evidence) * 9)
        confidence = min(96, raw)
        status = "strong" if confidence >= 60 else "partial" if confidence >= 30 else "absent"
        results.append({
            "stage": stage_id, "title": stage_titles[stage_id - 1], "confidence": confidence,
            "status": status, "matchedTerms": matches[:12], "evidenceSpans": evidence,
            "reason": "keyword-and-context-correspondence" if matches else "no-correspondence-located",
        })
    study_type, type_signals = infer_study_type(normalized)
    return {
        "engine": ENGINE, "engineVersion": ENGINE_VERSION, "rubricVersion": "general-12/v1",
        "studyType": study_type, "studyTypeSignals": type_signals,
        "wordCount": len(re.findall(r"\S+", normalized)), "characterCount": len(normalized),
        "stages": results,
        "warnings": [
            "confidence measures textual correspondence, not scientific quality or truth",
            "not located may mean omission, extraction failure, supplement location, terminology mismatch, or non-applicability",
        ],
    }
