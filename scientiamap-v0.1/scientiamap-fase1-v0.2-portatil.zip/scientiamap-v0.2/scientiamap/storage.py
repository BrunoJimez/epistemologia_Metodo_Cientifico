from __future__ import annotations

import hashlib
import json
import shutil
import sqlite3
import threading
from pathlib import Path
from typing import Any

from .models import (
    LANGUAGES,
    SCHEMA_VERSION,
    ValidationError,
    canonical_json,
    changed_paths,
    changed_stage_ids,
    new_id,
    normalize_project,
    project_title,
    utc_now,
)


class NotFoundError(KeyError):
    pass


class VersionConflictError(RuntimeError):
    def __init__(self, current: dict[str, Any]) -> None:
        super().__init__("versão do projeto mudou desde a última leitura")
        self.current = current


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._migrate()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=12)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 12000")
        return connection

    def _migrate(self) -> None:
        migration_dir = Path(__file__).with_name("migrations")
        with self._lock, self.connect() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
            applied = {row[0] for row in connection.execute("SELECT version FROM schema_migrations")}
            for migration in sorted(migration_dir.glob("[0-9][0-9][0-9]_*.sql")):
                version = int(migration.name.split("_", 1)[0])
                if version in applied:
                    continue
                connection.executescript(migration.read_text(encoding="utf-8"))
                connection.execute("INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)", (version, utc_now()))

    def health(self) -> dict[str, Any]:
        with self.connect() as connection:
            version = connection.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").fetchone()[0]
            projects = connection.execute("SELECT COUNT(*) FROM projects WHERE archived = 0").fetchone()[0]
        return {"database": "ok", "migration": version, "projects": projects, "path": str(self.path)}

    def _public_project(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "project": json.loads(row["payload_json"]),
            "lang": row["lang"],
            "version": row["version"],
            "sourceSchema": row["source_schema"],
            "createdAt": row["created_at"],
            "updatedAt": row["updated_at"],
            "archived": bool(row["archived"]),
        }

    def list_projects(self, include_archived: bool = False) -> list[dict[str, Any]]:
        where = "" if include_archived else "WHERE archived = 0"
        with self.connect() as connection:
            rows = connection.execute(
                f"SELECT id, title, lang, study_type, current_stage, version, archived, created_at, updated_at FROM projects {where} ORDER BY updated_at DESC"
            ).fetchall()
        return [
            {
                "id": row["id"], "title": row["title"], "lang": row["lang"],
                "studyType": row["study_type"], "currentStage": row["current_stage"],
                "version": row["version"], "archived": bool(row["archived"]),
                "createdAt": row["created_at"], "updatedAt": row["updated_at"],
            }
            for row in rows
        ]

    def get_project(self, project_id: str) -> dict[str, Any]:
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        if row is None:
            raise NotFoundError(project_id)
        return self._public_project(row)

    def create_project(
        self,
        project: dict[str, Any],
        *,
        lang: str = "pt-BR",
        source_schema: str = SCHEMA_VERSION,
        actor: str = "local-user",
        reason: str = "project-created",
    ) -> dict[str, Any]:
        clean = normalize_project(project)
        if lang not in LANGUAGES:
            raise ValidationError("idioma desconhecido", "$.lang")
        project_id, now, version = new_id(), utc_now(), 1
        clean["updatedAt"] = now
        payload = canonical_json(clean)
        with self._lock, self.connect() as connection:
            connection.execute(
                "INSERT INTO projects(id,title,lang,study_type,current_stage,payload_json,version,source_schema,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (project_id, project_title(clean), lang, clean["type"], clean["current"], payload, version, source_schema[:120], now, now),
            )
            connection.execute(
                "INSERT INTO project_versions(project_id,version,payload_json,reason,actor,created_at) VALUES (?,?,?,?,?,?)",
                (project_id, version, payload, reason[:200], actor[:120], now),
            )
            for stage_id in range(1, 13):
                self._insert_stage_revision(connection, project_id, stage_id, version, clean["stages"][str(stage_id)], reason, now)
            self._insert_audit(connection, project_id, version, "project.created", None, "Projeto criado", {"sourceSchema": source_schema}, actor, now)
        return self.get_project(project_id)

    def update_project(
        self,
        project_id: str,
        project: dict[str, Any],
        *,
        expected_version: int,
        lang: str | None = None,
        actor: str = "local-user",
        reason: str = "autosave",
    ) -> dict[str, Any]:
        clean = normalize_project(project)
        with self._lock, self.connect() as connection:
            row = connection.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
            if row is None:
                raise NotFoundError(project_id)
            if row["version"] != expected_version:
                raise VersionConflictError(self._public_project(row))
            previous = json.loads(row["payload_json"])
            paths = changed_paths(previous, clean)
            target_lang = lang or row["lang"]
            if target_lang not in LANGUAGES:
                raise ValidationError("idioma desconhecido", "$.lang")
            if not paths and target_lang == row["lang"]:
                return self._public_project(row)
            now, version = utc_now(), row["version"] + 1
            clean["updatedAt"] = now
            payload = canonical_json(clean)
            connection.execute(
                "UPDATE projects SET title=?,lang=?,study_type=?,current_stage=?,payload_json=?,version=?,updated_at=? WHERE id=?",
                (project_title(clean), target_lang, clean["type"], clean["current"], payload, version, now, project_id),
            )
            connection.execute(
                "INSERT INTO project_versions(project_id,version,payload_json,reason,actor,created_at) VALUES (?,?,?,?,?,?)",
                (project_id, version, payload, reason[:200], actor[:120], now),
            )
            stages = changed_stage_ids(paths)
            for stage_id in stages:
                self._insert_stage_revision(connection, project_id, stage_id, version, clean["stages"][str(stage_id)], reason, now)
            summary = "Projeto atualizado" if not stages else f"Etapas alteradas: {', '.join(map(str, stages))}"
            self._insert_audit(connection, project_id, version, "project.updated", stages[0] if len(stages) == 1 else None, summary, {"paths": paths[:200]}, actor, now)
        return self.get_project(project_id)

    def _insert_stage_revision(
        self, connection: sqlite3.Connection, project_id: str, stage_id: int, version: int,
        stage: dict[str, Any], reason: str, now: str,
    ) -> None:
        payload = canonical_json(stage)
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        connection.execute(
            "INSERT INTO stage_revisions(project_id,stage_id,project_version,content_hash,status,payload_json,reason,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (project_id, stage_id, version, digest, stage["status"], payload, reason[:200], now),
        )

    def _insert_audit(
        self, connection: sqlite3.Connection, project_id: str, version: int, event_type: str,
        stage_id: int | None, summary: str, details: dict[str, Any], actor: str, now: str,
    ) -> None:
        connection.execute(
            "INSERT INTO audit_events(project_id,project_version,event_type,stage_id,summary,details_json,actor,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (project_id, version, event_type, stage_id, summary[:500], canonical_json(details), actor[:120], now),
        )

    def versions(self, project_id: str, limit: int = 100) -> list[dict[str, Any]]:
        self.get_project(project_id)
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT id, version, reason, actor, created_at FROM project_versions WHERE project_id = ? ORDER BY version DESC LIMIT ?",
                (project_id, max(1, min(limit, 500))),
            ).fetchall()
        return [dict(row) for row in rows]

    def audit(self, project_id: str, limit: int = 200) -> list[dict[str, Any]]:
        self.get_project(project_id)
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT id,project_version,event_type,stage_id,summary,details_json,actor,created_at FROM audit_events WHERE project_id=? ORDER BY id DESC LIMIT ?",
                (project_id, max(1, min(limit, 1000))),
            ).fetchall()
        return [
            {
                "id": row["id"], "version": row["project_version"], "eventType": row["event_type"],
                "stageId": row["stage_id"], "summary": row["summary"],
                "details": json.loads(row["details_json"]), "actor": row["actor"], "createdAt": row["created_at"],
            }
            for row in rows
        ]

    def restore(self, project_id: str, target_version: int, *, expected_version: int, actor: str = "local-user") -> dict[str, Any]:
        with self.connect() as connection:
            row = connection.execute("SELECT payload_json FROM project_versions WHERE project_id=? AND version=?", (project_id, target_version)).fetchone()
        if row is None:
            raise NotFoundError(f"{project_id}@{target_version}")
        return self.update_project(
            project_id, json.loads(row["payload_json"]), expected_version=expected_version,
            actor=actor, reason=f"restored-from-v{target_version}",
        )

    def archive(self, project_id: str, *, expected_version: int, actor: str = "local-user") -> dict[str, Any]:
        with self._lock, self.connect() as connection:
            row = connection.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
            if row is None:
                raise NotFoundError(project_id)
            if row["version"] != expected_version:
                raise VersionConflictError(self._public_project(row))
            now, version = utc_now(), row["version"] + 1
            connection.execute("UPDATE projects SET archived=1,version=?,updated_at=? WHERE id=?", (version, now, project_id))
            connection.execute(
                "INSERT INTO project_versions(project_id,version,payload_json,reason,actor,created_at) VALUES (?,?,?,?,?,?)",
                (project_id, version, row["payload_json"], "project-archived", actor[:120], now),
            )
            self._insert_audit(connection, project_id, version, "project.archived", None, "Projeto arquivado", {}, actor, now)
        return self.get_project(project_id)

    def save_document(
        self, *, project_id: str | None, filename: str, media_type: str, sha256: str,
        byte_size: int, extracted_text: str, metadata: dict[str, Any], warnings: list[str],
    ) -> dict[str, Any]:
        if project_id:
            self.get_project(project_id)
        document_id, now = new_id("doc"), utc_now()
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO documents(id,project_id,filename,media_type,sha256,byte_size,extracted_text,metadata_json,warnings_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (document_id, project_id, filename[:500], media_type[:200], sha256, byte_size, extracted_text, canonical_json(metadata), canonical_json(warnings), now),
            )
        return {"id": document_id, "projectId": project_id, "filename": filename, "sha256": sha256, "byteSize": byte_size, "createdAt": now}

    def backup(self, destination: Path) -> Path:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with self._lock, self.connect() as source, sqlite3.connect(destination) as target:
            source.backup(target)
        return destination

