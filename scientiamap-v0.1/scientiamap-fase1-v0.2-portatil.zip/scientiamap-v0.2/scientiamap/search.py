from __future__ import annotations

import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path
from typing import Any, Callable

USER_AGENT = "ScientiaMap/0.2 (open research tool; local application)"
_ARXIV_LOCK = threading.Lock()
_ARXIV_LAST_REQUEST = 0.0


def _fetch(url: str, accept: str, timeout: int = 20) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": accept})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _json(url: str) -> dict[str, Any]:
    return json.loads(_fetch(url, "application/json").decode("utf-8"))


def _first_year(item: dict[str, Any]) -> int | None:
    for key in ("published-print", "published-online", "issued", "created"):
        parts = item.get(key, {}).get("date-parts", [])
        if parts and parts[0] and isinstance(parts[0][0], int):
            return parts[0][0]
    return None


def crossref(query: str, year_from: int | None, year_to: int | None) -> list[dict[str, Any]]:
    filters = []
    if year_from:
        filters.append(f"from-pub-date:{year_from}-01-01")
    if year_to:
        filters.append(f"until-pub-date:{year_to}-12-31")
    params = {
        "query.bibliographic": query, "rows": "15",
        "select": "DOI,title,author,published-print,published-online,issued,created,container-title,type,URL,license",
    }
    contact = os.environ.get("SCIENTIAMAP_CONTACT_EMAIL", "").strip()
    if contact and "@" in contact:
        params["mailto"] = contact
    if filters:
        params["filter"] = ",".join(filters)
    items = _json("https://api.crossref.org/works?" + urllib.parse.urlencode(params)).get("message", {}).get("items", [])
    results = []
    for rank, item in enumerate(items):
        authors = []
        for author in item.get("author", [])[:20]:
            name = " ".join(part for part in (author.get("given", ""), author.get("family", "")) if part).strip()
            if name:
                authors.append(name)
        title = " ".join(item.get("title") or []).strip()
        if title:
            results.append({
                "id": f"crossref:{item.get('DOI') or title}", "title": title, "authors": authors,
                "year": _first_year(item), "venue": " ".join(item.get("container-title") or []),
                "doi": item.get("DOI"), "url": item.get("URL"), "source": "Crossref",
                "type": item.get("type"), "openAccess": bool(item.get("license")), "sourceRank": rank,
            })
    return results


def europe_pmc(query: str, year_from: int | None, year_to: int | None) -> list[dict[str, Any]]:
    q = query
    if year_from or year_to:
        q += f" AND FIRST_PDATE:[{year_from or 1000}-01-01 TO {year_to or 3000}-12-31]"
    params = {"query": q, "format": "json", "pageSize": "15", "resultType": "core"}
    items = _json("https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urllib.parse.urlencode(params)).get("resultList", {}).get("result", [])
    results = []
    for rank, item in enumerate(items):
        title = re.sub(r"<[^>]+>", "", item.get("title", "")).strip()
        if not title:
            continue
        doi, pmcid, pmid = item.get("doi"), item.get("pmcid"), item.get("pmid")
        url = f"https://europepmc.org/article/MED/{pmid}" if pmid else (f"https://europepmc.org/article/PMC/{pmcid}" if pmcid else (f"https://doi.org/{doi}" if doi else ""))
        results.append({
            "id": f"epmc:{pmcid or pmid or doi or title}", "title": title,
            "authors": [part.strip() for part in item.get("authorString", "").rstrip(".").split(",") if part.strip()],
            "year": int(item["pubYear"]) if str(item.get("pubYear", "")).isdigit() else None,
            "venue": item.get("journalTitle", ""), "doi": doi, "url": url, "source": "Europe PMC",
            "type": item.get("pubType", ""), "openAccess": item.get("isOpenAccess") == "Y", "sourceRank": rank,
        })
    return results


def arxiv(query: str, year_from: int | None, year_to: int | None) -> list[dict[str, Any]]:
    global _ARXIV_LAST_REQUEST
    with _ARXIV_LOCK:
        wait = 3.05 - (time.monotonic() - _ARXIV_LAST_REQUEST)
        if wait > 0:
            time.sleep(wait)
        params = {"search_query": f"all:{query}", "start": "0", "max_results": "12", "sortBy": "relevance"}
        raw = _fetch("https://export.arxiv.org/api/query?" + urllib.parse.urlencode(params), "application/atom+xml").decode("utf-8")
        _ARXIV_LAST_REQUEST = time.monotonic()
    ns = {"a": "http://www.w3.org/2005/Atom"}
    root, results = ET.fromstring(raw), []
    for rank, entry in enumerate(root.findall("a:entry", ns)):
        published = entry.findtext("a:published", "", ns)
        year = int(published[:4]) if published[:4].isdigit() else None
        if (year_from and year and year < year_from) or (year_to and year and year > year_to):
            continue
        title = " ".join(entry.findtext("a:title", "", ns).split())
        if title:
            url = entry.findtext("a:id", "", ns)
            results.append({
                "id": f"arxiv:{url.rsplit('/', 1)[-1]}", "title": title,
                "authors": [node.findtext("a:name", "", ns) for node in entry.findall("a:author", ns)],
                "year": year, "venue": "arXiv", "doi": None, "url": url, "source": "arXiv",
                "type": "preprint", "openAccess": True, "sourceRank": rank,
            })
    return results


def _normalize_title(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", title.casefold())[:240]


class SearchService:
    def __init__(self, cache_dir: Path, ttl_hours: int = 24) -> None:
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl = timedelta(hours=ttl_hours)
        self.sources: dict[str, Callable[[str, int | None, int | None], list[dict[str, Any]]]] = {
            "Crossref": crossref, "Europe PMC": europe_pmc, "arXiv": arxiv,
        }

    def _cache_path(self, query: str, year_from: int | None, year_to: int | None) -> Path:
        key = sha256(f"v2|{query.casefold()}|{year_from}|{year_to}".encode()).hexdigest()
        return self.cache_dir / f"{key}.json"

    def search(self, query: str, year_from: int | None = None, year_to: int | None = None, *, refresh: bool = False) -> dict[str, Any]:
        query = query.strip()
        if not 2 <= len(query) <= 300:
            raise ValueError("consulta deve ter entre 2 e 300 caracteres")
        if year_from and not 1000 <= year_from <= 3000 or year_to and not 1000 <= year_to <= 3000:
            raise ValueError("ano deve estar entre 1000 e 3000")
        if year_from and year_to and year_from > year_to:
            raise ValueError("ano inicial não pode ser posterior ao final")
        cache = self._cache_path(query, year_from, year_to)
        if cache.exists() and not refresh:
            try:
                payload = json.loads(cache.read_text(encoding="utf-8"))
                created = datetime.fromisoformat(payload["createdAt"].replace("Z", "+00:00"))
                if datetime.now(UTC) - created < self.ttl:
                    payload["cache"] = "hit"
                    return payload
            except (ValueError, KeyError, json.JSONDecodeError):
                pass

        started = time.monotonic()
        gathered, errors = [], []
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = {pool.submit(source, query, year_from, year_to): name for name, source in self.sources.items()}
            for future in as_completed(futures):
                name = futures[future]
                try:
                    gathered.extend(future.result())
                except Exception as exc:
                    errors.append({"source": name, "error": type(exc).__name__})
        deduped: dict[str, dict[str, Any]] = {}
        for item in gathered:
            key = (item.get("doi") or "").casefold() or _normalize_title(item.get("title", ""))
            if not key:
                continue
            if key in deduped:
                current = deduped[key]
                current["sources"] = sorted(set(current["sources"] + [item["source"]]))
                current["openAccess"] = bool(current.get("openAccess") or item.get("openAccess"))
                current["sourceRank"] = min(current.get("sourceRank", 99), item.get("sourceRank", 99))
                if not current.get("url"):
                    current["url"] = item.get("url")
            else:
                item["sources"] = [item.pop("source")]
                deduped[key] = item
        results = list(deduped.values())
        results.sort(key=lambda item: (item.get("sourceRank", 99), -(item.get("year") or 0), item.get("title", "")))
        for item in results:
            item["source"] = " + ".join(item.pop("sources"))
            item.pop("sourceRank", None)
        payload = {
            "query": query, "yearFrom": year_from, "yearTo": year_to, "results": results[:40],
            "sourceErrors": errors, "elapsedMs": round((time.monotonic() - started) * 1000),
            "createdAt": datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z"), "cache": "miss",
            "warning": "federated discovery is not an exhaustive systematic-review search",
        }
        temporary = cache.with_name(f"{cache.name}.{threading.get_ident()}.tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(temporary, cache)
        return payload
