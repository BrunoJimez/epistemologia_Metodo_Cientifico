from __future__ import annotations

from typing import Any

STAGE_TITLES: dict[str, list[str]] = {
    "pt-BR": [
        "Fenômeno e problema", "Pergunta investigável", "Conhecimento prévio e hipótese",
        "Conceitos e definições operacionais", "Modelo, idealizações e domínio",
        "Representação matemática ou computacional", "Consequências e predições",
        "Desenho do estudo e instrumentos", "Intervenção, observação e dados",
        "Análise e incerteza", "Confronto entre previsão e mundo",
        "Comunicação, crítica e replicação",
    ],
    "en": [
        "Phenomenon and problem", "Researchable question", "Prior knowledge and hypothesis",
        "Concepts and operational definitions", "Model, idealizations, and domain",
        "Mathematical or computational representation", "Consequences and predictions",
        "Study and instrument design", "Intervention, observation, and data",
        "Analysis and uncertainty", "Confronting prediction with the world",
        "Communication, critique, and replication",
    ],
    "es": [
        "Fenómeno y problema", "Pregunta investigable", "Conocimiento previo e hipótesis",
        "Conceptos y definiciones operacionales", "Modelo, idealizaciones y dominio",
        "Representación matemática o computacional", "Consecuencias y predicciones",
        "Diseño del estudio e instrumentos", "Intervención, observación y datos",
        "Análisis e incertidumbre", "Contraste entre predicción y mundo",
        "Comunicación, crítica y replicación",
    ],
    "zh-CN": [
        "现象与问题", "可研究的问题", "先验知识与假设", "概念与操作性定义",
        "模型、理想化与适用域", "数学或计算表征", "推论与预测", "研究与仪器设计",
        "干预、观察与数据", "分析与不确定性", "预测与现实的对照", "传播、批评与复现",
    ],
}

LABELS: dict[str, dict[str, str]] = {
    "pt-BR": {"question": "Pergunta", "evidence": "Evidência, fonte ou decisão", "limits": "Incerteza, risco ou limitação", "status": "Estado", "caveat": "Ressalva", "checks": "Critérios declarados", "warning": "Aviso epistemológico"},
    "en": {"question": "Question", "evidence": "Evidence, source, or decision", "limits": "Uncertainty, risk, or limitation", "status": "Status", "caveat": "Caveat", "checks": "Declared criteria", "warning": "Epistemic warning"},
    "es": {"question": "Pregunta", "evidence": "Evidencia, fuente o decisión", "limits": "Incertidumbre, riesgo o limitación", "status": "Estado", "caveat": "Salvedad", "checks": "Criterios declarados", "warning": "Aviso epistemológico"},
    "zh-CN": {"question": "问题", "evidence": "证据、来源或决策", "limits": "不确定性、风险或局限", "status": "状态", "caveat": "保留意见", "checks": "已声明标准", "warning": "认识论提示"},
}

WARNINGS: dict[str, str] = {
    "pt-BR": "Etapa pronta significa documentação mínima explicitada; não certifica verdade, validade, ética ou qualidade estatística.",
    "en": "A ready stage means minimum documentation was made explicit; it does not certify truth, validity, ethics, or statistical quality.",
    "es": "Una etapa lista significa documentación mínima explícita; no certifica verdad, validez, ética ni calidad estadística.",
    "zh-CN": "阶段就绪仅表示最低文档要素已明确；不证明真实性、有效性、伦理性或统计质量。",
}


def titles(lang: str) -> list[str]:
    return STAGE_TITLES.get(lang, STAGE_TITLES["pt-BR"])


def labels(lang: str) -> dict[str, str]:
    return LABELS.get(lang, LABELS["pt-BR"])


def warning(lang: str) -> str:
    return WARNINGS.get(lang, WARNINGS["pt-BR"])


def stage_completion(stage: dict[str, Any]) -> dict[str, Any]:
    tests = {
        "mainText": len(stage.get("main", "").strip()) >= 80,
        "evidence": len(stage.get("evidence", "").strip()) >= 40,
        "limitations": len(stage.get("limits", "").strip()) >= 25,
        "checks": stage.get("checks") == [True, True, True],
    }
    return {"complete": all(tests.values()), "tests": tests, "kind": "documentary-completeness"}

