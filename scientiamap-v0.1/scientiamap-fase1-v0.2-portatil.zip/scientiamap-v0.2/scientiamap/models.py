from __future__ import annotations

import copy
import json
import re
import uuid
from datetime import UTC, datetime
from typing import Any

LANGUAGES = {"pt-BR", "en", "es", "zh-CN"}
STUDY_TYPES = {
    "generic",
    "experimental",
    "observational",
    "randomized",
    "systematic",
    "computational",
    "theoretical",
    "qualitative",
}
STAGE_STATUSES = {"open", "ready", "override"}
SCHEMA_VERSION = "scientiamap-project/v2"


class ValidationError(ValueError):
    """Raised when a project violates the public project schema."""

    def __init__(self, message: str, path: str = "$") -> None:
        super().__init__(message)
        self.path = path

    def as_dict(self) -> dict[str, str]:
        return {"message": str(self), "path": self.path}


def utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def new_id(prefix: str = "prj") -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def empty_stage() -> dict[str, Any]:
    return {
        "main": "",
        "evidence": "",
        "limits": "",
        "checks": [False, False, False],
        "status": "open",
        "overrideReason": "",
    }


def empty_project() -> dict[str, Any]:
    return {
        "title": "",
        "question": "",
        "type": "generic",
        "current": 1,
        "updatedAt": utc_now(),
        "stages": {str(index): empty_stage() for index in range(1, 13)},
    }


def _text(value: Any, *, maximum: int, path: str) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValidationError("deve ser texto", path)
    if len(value) > maximum:
        raise ValidationError(f"excede {maximum} caracteres", path)
    return value.replace("\x00", "")


def normalize_project(raw: Any) -> dict[str, Any]:
    """Validate and normalize v0.1/v0.2 browser project payloads.

    Unknown top-level fields are intentionally discarded. This makes imports
    predictable and prevents untrusted JSON from being reflected later.
    """
    if not isinstance(raw, dict):
        raise ValidationError("o projeto deve ser um objeto JSON")

    result = empty_project()
    result["title"] = _text(raw.get("title", ""), maximum=500, path="$.title")
    result["question"] = _text(raw.get("question", ""), maximum=20_000, path="$.question")
    study_type = raw.get("type", "generic")
    if study_type not in STUDY_TYPES:
        raise ValidationError("tipo de estudo desconhecido", "$.type")
    result["type"] = study_type

    current = raw.get("current", 1)
    if not isinstance(current, int) or isinstance(current, bool) or not 1 <= current <= 12:
        raise ValidationError("deve ser inteiro entre 1 e 12", "$.current")
    result["current"] = current

    source_stages = raw.get("stages", {})
    if not isinstance(source_stages, dict):
        raise ValidationError("deve ser um objeto com 12 etapas", "$.stages")
    for index in range(1, 13):
        source = source_stages.get(str(index), source_stages.get(index, {}))
        if not isinstance(source, dict):
            raise ValidationError("deve ser um objeto", f"$.stages.{index}")
        stage = empty_stage()
        stage["main"] = _text(source.get("main", ""), maximum=200_000, path=f"$.stages.{index}.main")
        stage["evidence"] = _text(source.get("evidence", ""), maximum=200_000, path=f"$.stages.{index}.evidence")
        stage["limits"] = _text(source.get("limits", ""), maximum=200_000, path=f"$.stages.{index}.limits")
        stage["overrideReason"] = _text(source.get("overrideReason", ""), maximum=20_000, path=f"$.stages.{index}.overrideReason")
        checks = source.get("checks", [False, False, False])
        if not isinstance(checks, list) or len(checks) != 3 or any(type(item) is not bool for item in checks):
            raise ValidationError("deve conter exatamente três booleanos", f"$.stages.{index}.checks")
        stage["checks"] = checks.copy()
        status = source.get("status", "open")
        if status not in STAGE_STATUSES:
            raise ValidationError("estado de etapa desconhecido", f"$.stages.{index}.status")
        if status == "override" and len(stage["overrideReason"].strip()) < 20:
            raise ValidationError("ressalva exige justificativa com ao menos 20 caracteres", f"$.stages.{index}.overrideReason")
        stage["status"] = status
        result["stages"][str(index)] = stage

    updated_at = raw.get("updatedAt")
    result["updatedAt"] = updated_at if isinstance(updated_at, str) and len(updated_at) <= 40 else utc_now()
    return result


def unwrap_import(raw: Any) -> tuple[dict[str, Any], str]:
    """Accept a bare v0.1 project or an exported v1/v2 envelope."""
    if not isinstance(raw, dict):
        raise ValidationError("arquivo JSON inválido")
    schema = raw.get("schema", "scientiamap-project/v0.1-bare")
    project = raw.get("project", raw)
    return normalize_project(project), str(schema)[:120]


def project_title(project: dict[str, Any]) -> str:
    title = project.get("title", "").strip()
    return title or "Projeto sem título"


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def changed_paths(old: Any, new: Any, prefix: str = "$") -> list[str]:
    if type(old) is not type(new):
        return [prefix]
    if isinstance(old, dict):
        changes: list[str] = []
        for key in sorted(set(old) | set(new), key=str):
            child = f"{prefix}.{key}"
            if key not in old or key not in new:
                changes.append(child)
            else:
                changes.extend(changed_paths(old[key], new[key], child))
        return changes
    if isinstance(old, list):
        if len(old) != len(new):
            return [prefix]
        changes = []
        for index, (left, right) in enumerate(zip(old, new)):
            changes.extend(changed_paths(left, right, f"{prefix}[{index}]"))
        return changes
    return [] if old == new else [prefix]


def changed_stage_ids(paths: list[str]) -> list[int]:
    found: set[int] = set()
    for path in paths:
        match = re.match(r"^\$\.stages\.(\d+)(?:\.|$)", path)
        if match and 1 <= int(match.group(1)) <= 12:
            found.add(int(match.group(1)))
    return sorted(found)


def copy_project(project: dict[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(project)

