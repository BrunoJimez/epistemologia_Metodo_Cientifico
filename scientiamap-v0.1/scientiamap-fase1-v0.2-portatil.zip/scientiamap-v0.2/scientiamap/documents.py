from __future__ import annotations

import hashlib
import io
import json
import re
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

MAX_FILE_BYTES = 25 * 1024 * 1024
MAX_ARCHIVE_UNCOMPRESSED = 120 * 1024 * 1024
MAX_TEXT_CHARS = 5_000_000


class DocumentError(ValueError):
    pass


class MissingDependencyError(DocumentError):
    def __init__(self, package: str, feature: str) -> None:
        super().__init__(f"{feature} requer o pacote livre {package}")
        self.package = package


class _TextHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "template"}:
            self.skip += 1
        if tag in {"p", "div", "section", "article", "br", "li", "h1", "h2", "h3", "h4", "tr"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "template"} and self.skip:
            self.skip -= 1

    def handle_data(self, data: str) -> None:
        if not self.skip:
            self.parts.append(data)

    def text(self) -> str:
        return re.sub(r"\n{3,}", "\n\n", "".join(self.parts)).strip()


def _safe_zip(data: bytes) -> None:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = archive.infolist()
            if len(members) > 5_000:
                raise DocumentError("arquivo compactado contém entradas demais")
            total = sum(item.file_size for item in members)
            compressed = max(1, sum(item.compress_size for item in members))
            if total > MAX_ARCHIVE_UNCOMPRESSED:
                raise DocumentError("arquivo compactado excede o limite descomprimido")
            if total / compressed > 200:
                raise DocumentError("taxa de compressão do arquivo é insegura")
    except zipfile.BadZipFile as exc:
        raise DocumentError("arquivo Office inválido") from exc


def _decode_text(data: bytes) -> tuple[str, str]:
    for encoding in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            return data.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    raise DocumentError("codificação de texto não reconhecida")


def extract_document(filename: str, data: bytes, media_type: str = "application/octet-stream") -> dict[str, Any]:
    if not isinstance(data, bytes):
        raise DocumentError("conteúdo deve ser binário")
    if not data:
        raise DocumentError("arquivo vazio")
    if len(data) > MAX_FILE_BYTES:
        raise DocumentError("arquivo excede 25 MiB")
    name = Path(filename.replace("\\", "/")).name[:500]
    extension = Path(name).suffix.casefold()
    warnings: list[str] = []
    metadata: dict[str, Any] = {"extension": extension}

    if extension == ".pdf" or media_type == "application/pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise MissingDependencyError("pypdf", "leitura de PDF") from exc
        try:
            reader = PdfReader(io.BytesIO(data), strict=False)
            if len(reader.pages) > 600:
                raise DocumentError("PDF excede 600 páginas")
            pages = []
            for index, page in enumerate(reader.pages, start=1):
                extracted = page.extract_text() or ""
                if not extracted.strip():
                    warnings.append(f"página {index}: nenhum texto extraído; pode exigir OCR")
                pages.append(f"\n\n[PAGE {index}]\n{extracted}")
            text = "".join(pages).strip()
            metadata.update({"pages": len(reader.pages), "pdfMetadata": {str(k): str(v) for k, v in (reader.metadata or {}).items()}})
        except DocumentError:
            raise
        except Exception as exc:
            raise DocumentError(f"não foi possível ler o PDF: {type(exc).__name__}") from exc
    elif extension == ".docx" or media_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        _safe_zip(data)
        try:
            from docx import Document
        except ImportError as exc:
            raise MissingDependencyError("python-docx", "leitura de DOCX") from exc
        document = Document(io.BytesIO(data))
        parts = [paragraph.text for paragraph in document.paragraphs]
        for table_index, table in enumerate(document.tables, start=1):
            parts.append(f"\n[TABLE {table_index}]")
            for row in table.rows:
                parts.append("\t".join(cell.text for cell in row.cells))
        text = "\n".join(parts)
        metadata.update({"paragraphs": len(document.paragraphs), "tables": len(document.tables)})
    elif extension == ".xlsx" or media_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        _safe_zip(data)
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise MissingDependencyError("openpyxl", "leitura de XLSX") from exc
        workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=False)
        parts, cells = [], 0
        for sheet in workbook.worksheets:
            parts.append(f"\n[SHEET {sheet.title}]")
            for row in sheet.iter_rows(values_only=True):
                values = ["" if value is None else str(value) for value in row]
                cells += len(values)
                if cells > 250_000:
                    warnings.append("extração interrompida após 250.000 células")
                    break
                if any(values):
                    parts.append("\t".join(values))
            if cells > 250_000:
                break
        workbook.close()
        text = "\n".join(parts)
        metadata.update({"sheets": workbook.sheetnames, "cellsVisited": cells})
    else:
        text, encoding = _decode_text(data)
        metadata["encoding"] = encoding
        if extension in {".html", ".htm"} or "html" in media_type:
            parser = _TextHTMLParser()
            parser.feed(text)
            text = parser.text()
        elif extension == ".json" or media_type == "application/json":
            try:
                text = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                warnings.append("extensão JSON, mas conteúdo não pôde ser validado")

    if len(text) > MAX_TEXT_CHARS:
        text = text[:MAX_TEXT_CHARS]
        warnings.append("texto truncado em 5 milhões de caracteres")
    if not text.strip():
        warnings.append("nenhum texto utilizável foi extraído")
    digest = hashlib.sha256(data).hexdigest()
    return {
        "filename": name, "mediaType": media_type, "sha256": digest, "byteSize": len(data),
        "text": text, "metadata": metadata, "warnings": warnings,
        "extractor": "scientiamap-document-extractor", "extractorVersion": "0.2.0",
    }
