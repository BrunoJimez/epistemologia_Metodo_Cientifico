#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"
if [ -x ".venv/bin/python" ]; then
  exec ".venv/bin/python" run.py --data-dir "$SCRIPT_DIR/data"
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 run.py --data-dir "$SCRIPT_DIR/data"
fi
echo "Python 3.11 ou superior não foi encontrado." >&2
exit 2
