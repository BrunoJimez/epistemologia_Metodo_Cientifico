#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import threading
import urllib.request
import webbrowser
from datetime import UTC, datetime
from http.server import ThreadingHTTPServer
from pathlib import Path

from scientiamap import __version__
from scientiamap.api import ScientiaHandler
from scientiamap.search import SearchService
from scientiamap.storage import Database

ROOT = Path(__file__).resolve().parent


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ScientiaMap local-first research environment")
    parser.add_argument("--host", default="127.0.0.1", help="bind address; keep 127.0.0.1 unless you understand the exposure risk")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--debug", action="store_true")
    return parser.parse_args()


def existing_server(url: str) -> bool:
    try:
        with urllib.request.urlopen(url + "api/health", timeout=1.5) as response:
            return response.status == 200
    except Exception:
        return False


def daily_backup(database: Database, data_dir: Path) -> None:
    if not database.path.exists() or database.path.stat().st_size == 0:
        return
    stamp = datetime.now(UTC).strftime("%Y-%m-%d")
    destination = data_dir / "backups" / f"automatic-{stamp}.sqlite3"
    if not destination.exists():
        database.backup(destination)


def main() -> int:
    args = parse_args()
    if not 0 <= args.port <= 65535:
        print("Porta inválida.", file=sys.stderr)
        return 2
    if args.host not in {"127.0.0.1", "localhost", "::1"}:
        print("ATENÇÃO: o ScientiaMap será exposto na rede. Use apenas em ambiente confiável.")
    data_dir = args.data_dir.resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    url = f"http://{args.host}:{args.port}/"
    if args.port and existing_server(url):
        print(f"ScientiaMap já está aberto em {url}")
        if not args.no_browser:
            webbrowser.open(url)
        return 0

    database = Database(data_dir / "scientiamap.sqlite3")
    daily_backup(database, data_dir)
    ScientiaHandler.database = database
    ScientiaHandler.search_service = SearchService(data_dir / "cache" / "search")
    ScientiaHandler.web_root = ROOT / "web"
    ScientiaHandler.data_dir = data_dir
    ScientiaHandler.debug = args.debug
    server = Server((args.host, args.port), ScientiaHandler)
    actual_port = server.server_address[1]
    url = f"http://{args.host}:{actual_port}/"
    print(f"ScientiaMap {__version__} disponível em {url}")
    print(f"Dados locais: {data_dir}")
    print("Pressione Ctrl+C para encerrar.")
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nScientiaMap encerrado com segurança.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
