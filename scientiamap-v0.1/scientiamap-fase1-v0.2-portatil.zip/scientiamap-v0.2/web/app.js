"use strict";

const LANGS = ["pt-BR", "en", "es", "zh-CN"];
const STUDY_KEYS = ["generic", "experimental", "observational", "randomized", "systematic", "computational", "theoretical", "qualitative"];

const TEXT = {
  "pt-BR": {
    eyebrow:"Laboratório metodológico aberto",hero:"Da dúvida ao estudo — sem transformar checklist em verdade.",intro:"Organize perguntas, evidências, modelos, dados e crítica em 12 etapas iterativas. O sistema avalia completude documental; pessoas e comunidades científicas avaliam validade.",local:"Salvo neste dispositivo",audit:"Decisões auditáveis",free:"Fontes sem API paga",navBuild:"Construir estudo",navAnalyze:"Analisar artigo",navMap:"Mapa metodológico",navSearch:"Buscar literatura",project:"Projeto de pesquisa",workingTitle:"Título provisório",question:"Dúvida ou pergunta inicial",studyType:"Tipo de estudo",progress:"Progresso documentado",stage:"Etapa",purpose:"Finalidade",mainRecord:"Registro principal",evidence:"Evidência, fonte ou decisão",limits:"Incerteza, risco ou limitação",readiness:"Critérios de prontidão",gate:"Porta transparente: texto principal ≥ 80 caracteres; evidência/decisão ≥ 40; limitação ≥ 25; todos os itens marcados.",previous:"Anterior",autosave:"Salvo automaticamente",reopen:"Reabrir etapa",caveat:"Avançar com ressalva",validate:"Validar e avançar",lockedNext:"A etapa seguinte permanece bloqueada até esta ficar pronta.",overrideReason:"Justifique a ressalva (mínimo 20 caracteres)",recordCaveat:"Registrar ressalva",exportProject:"Exportar projeto",importJson:"Importar JSON",safety:"ScientiaMap não substitui orientação especializada, comitê de ética, revisão estatística, revisão por pares ou julgamento clínico.",analyzeTitle:"Decompositor de artigo",analyzeIntro:"Cole o texto integral ou carregue um arquivo textual. A análise procura conteúdo — não apenas títulos — e associa trechos às 12 etapas.",textFile:"Arquivo textual",articleText:"Texto do artigo",analyzeAction:"Analisar conteúdo",heuristic:"Análise heurística local. Confiança mede correspondência textual, não qualidade, veracidade nem risco de viés.",mapTitle:"O método é uma rede com retornos, não uma escada irreversível",mapIntro:"As portas ajudam a não pular documentação essencial. Resultados inesperados podem obrigar o pesquisador a voltar ao conceito, modelo, predição, instrumento ou análise.",conceptual:"Construção conceitual",empirical:"Confronto empírico",publicCritique:"Crítica pública",returns:"Retornos permitidos e registrados",mapNote:"Prontidão significa: os elementos mínimos foram explicitados. Não significa: a hipótese é verdadeira, o desenho é ético ou a análise está correta.",searchTitle:"Descoberta federada de literatura",searchIntro:"Busca metadados em Crossref, Europe PMC e arXiv. É ampla, mas não exaustiva: bases têm coberturas e políticas diferentes.",query:"Tema, título, autor, DOI ou palavras-chave",yearFrom:"Ano inicial",yearTo:"Ano final",searchAction:"Buscar",paywall:"A plataforma nunca contorna paywalls. Ela aponta metadados e textos legalmente abertos, preservando DOI, fonte e licença quando disponíveis.",sourcesLimits:"Fontes e limites da versão",sourceText:"A arquitetura de produção prevê também OpenAlex por chave gratuita ou snapshot local, PubMed/PMC, DOAJ, SciELO e repositórios OAI-PMH. Nenhuma fonte isolada representa “todos os estudos”.",newProject:"Novo projeto",confirmReset:"Apagar o projeto salvo neste dispositivo e começar outro?",ready:"Pronta",open:"Em elaboração",locked:"Bloqueada",overridden:"Com ressalva",incomplete:"Ainda faltam elementos para considerar a etapa documentada.",likelyType:"Tipo provável",words:"palavras",coverage:"Cobertura",confidence:"confiança",snippets:"trechos localizados",none:"Nenhum trecho localizado",strong:"forte",partial:"parcial",absent:"não localizado",searching:"Buscando nas fontes…",searchError:"Não foi possível consultar as fontes agora.",noResults:"Nenhum resultado. Tente sinônimos ou retire o filtro de ano.",results:"resultados consolidados",openText:"texto aberto indicado",unknownDate:"s.d.",types:["Ainda não sei","Experimental","Observacional","Ensaio randomizado","Revisão sistemática","Computacional/simulação","Teórico/matemático","Qualitativo"]
  },
  en: {
    eyebrow:"Open methodology lab",hero:"From doubt to study — without turning a checklist into truth.",intro:"Organize questions, evidence, models, data, and critique in 12 iterative stages. The system evaluates documentary completeness; scientific communities evaluate validity.",local:"Saved on this device",audit:"Auditable decisions",free:"No paid APIs",navBuild:"Build study",navAnalyze:"Analyze article",navMap:"Method map",navSearch:"Search literature",project:"Research project",workingTitle:"Working title",question:"Initial doubt or question",studyType:"Study type",progress:"Documented progress",stage:"Stage",purpose:"Purpose",mainRecord:"Main record",evidence:"Evidence, source, or decision",limits:"Uncertainty, risk, or limitation",readiness:"Readiness criteria",gate:"Transparent gate: main text ≥ 80 characters; evidence/decision ≥ 40; limitation ≥ 25; all items checked.",previous:"Previous",autosave:"Saved automatically",reopen:"Reopen stage",caveat:"Continue with caveat",validate:"Validate and continue",lockedNext:"The next stage remains locked until this one is ready.",overrideReason:"Explain the caveat (at least 20 characters)",recordCaveat:"Record caveat",exportProject:"Export project",importJson:"Import JSON",safety:"ScientiaMap does not replace expert guidance, ethics review, statistical review, peer review, or clinical judgment.",analyzeTitle:"Article decomposer",analyzeIntro:"Paste full text or load a textual file. The analysis seeks content—not headings alone—and maps excerpts to the 12 stages.",textFile:"Text file",articleText:"Article text",analyzeAction:"Analyze content",heuristic:"Local heuristic analysis. Confidence measures textual correspondence, not quality, truth, or risk of bias.",mapTitle:"The method is a network with returns, not an irreversible ladder",mapIntro:"Gates help prevent missing essential documentation. Unexpected results may require a return to concepts, model, prediction, instrument, or analysis.",conceptual:"Conceptual construction",empirical:"Empirical confrontation",publicCritique:"Public critique",returns:"Returns are allowed and recorded",mapNote:"Readiness means minimum elements were made explicit. It does not mean the hypothesis is true, the design is ethical, or the analysis is correct.",searchTitle:"Federated literature discovery",searchIntro:"Searches metadata from Crossref, Europe PMC, and arXiv. It is broad but not exhaustive: databases have different coverage and policies.",query:"Topic, title, author, DOI, or keywords",yearFrom:"From year",yearTo:"To year",searchAction:"Search",paywall:"The platform never circumvents paywalls. It points to metadata and lawfully open texts while preserving DOI, source, and license when available.",sourcesLimits:"Sources and limits",sourceText:"The production architecture also plans OpenAlex through a free key or local snapshot, PubMed/PMC, DOAJ, SciELO, and OAI-PMH repositories. No single source represents ‘all studies’.",newProject:"New project",confirmReset:"Delete the project saved on this device and start another?",ready:"Ready",open:"In progress",locked:"Locked",overridden:"With caveat",incomplete:"Some elements are still missing before the stage is documented.",likelyType:"Likely type",words:"words",coverage:"Coverage",confidence:"confidence",snippets:"located excerpts",none:"No excerpt located",strong:"strong",partial:"partial",absent:"not located",searching:"Searching sources…",searchError:"The sources could not be queried right now.",noResults:"No results. Try synonyms or remove the year filter.",results:"consolidated results",openText:"open text indicated",unknownDate:"n.d.",types:["Not sure yet","Experimental","Observational","Randomized trial","Systematic review","Computational/simulation","Theoretical/mathematical","Qualitative"]
  },
  es: {
    eyebrow:"Laboratorio metodológico abierto",hero:"De la duda al estudio, sin convertir una lista en verdad.",intro:"Organice preguntas, evidencia, modelos, datos y crítica en 12 etapas iterativas. El sistema evalúa integridad documental; la comunidad científica evalúa validez.",local:"Guardado en este dispositivo",audit:"Decisiones auditables",free:"Sin API de pago",navBuild:"Construir estudio",navAnalyze:"Analizar artículo",navMap:"Mapa metodológico",navSearch:"Buscar literatura",project:"Proyecto de investigación",workingTitle:"Título provisional",question:"Duda o pregunta inicial",studyType:"Tipo de estudio",progress:"Progreso documentado",stage:"Etapa",purpose:"Finalidad",mainRecord:"Registro principal",evidence:"Evidencia, fuente o decisión",limits:"Incertidumbre, riesgo o limitación",readiness:"Criterios de preparación",gate:"Puerta transparente: texto principal ≥ 80 caracteres; evidencia/decisión ≥ 40; limitación ≥ 25; todos los ítems marcados.",previous:"Anterior",autosave:"Guardado automático",reopen:"Reabrir etapa",caveat:"Avanzar con salvedad",validate:"Validar y avanzar",lockedNext:"La etapa siguiente sigue bloqueada hasta completar esta.",overrideReason:"Justifique la salvedad (mínimo 20 caracteres)",recordCaveat:"Registrar salvedad",exportProject:"Exportar proyecto",importJson:"Importar JSON",safety:"ScientiaMap no reemplaza tutoría experta, comité de ética, revisión estadística, revisión por pares ni juicio clínico.",analyzeTitle:"Descompositor de artículo",analyzeIntro:"Pegue el texto completo o cargue un archivo textual. El análisis busca contenido y asocia fragmentos a las 12 etapas.",textFile:"Archivo textual",articleText:"Texto del artículo",analyzeAction:"Analizar contenido",heuristic:"Análisis heurístico local. La confianza mide coincidencia textual, no calidad, verdad ni riesgo de sesgo.",mapTitle:"El método es una red con retornos, no una escalera irreversible",mapIntro:"Las puertas evitan omitir documentación esencial. Resultados inesperados pueden exigir volver a conceptos, modelo, predicción, instrumento o análisis.",conceptual:"Construcción conceptual",empirical:"Contraste empírico",publicCritique:"Crítica pública",returns:"Retornos permitidos y registrados",mapNote:"Preparación significa que se explicitaron elementos mínimos; no que la hipótesis sea verdadera, el diseño ético o el análisis correcto.",searchTitle:"Descubrimiento federado de literatura",searchIntro:"Busca metadatos en Crossref, Europe PMC y arXiv. Es amplia, no exhaustiva: las bases tienen coberturas distintas.",query:"Tema, título, autor, DOI o palabras clave",yearFrom:"Año inicial",yearTo:"Año final",searchAction:"Buscar",paywall:"La plataforma nunca elude muros de pago. Señala metadatos y textos legalmente abiertos, preservando DOI, fuente y licencia cuando estén disponibles.",sourcesLimits:"Fuentes y límites",sourceText:"La arquitectura prevé también OpenAlex con clave gratuita o instantánea local, PubMed/PMC, DOAJ, SciELO y repositorios OAI-PMH. Ninguna fuente representa «todos los estudios».",newProject:"Nuevo proyecto",confirmReset:"¿Borrar el proyecto guardado en este dispositivo y comenzar otro?",ready:"Lista",open:"En elaboración",locked:"Bloqueada",overridden:"Con salvedad",incomplete:"Todavía faltan elementos para documentar la etapa.",likelyType:"Tipo probable",words:"palabras",coverage:"Cobertura",confidence:"confianza",snippets:"fragmentos encontrados",none:"Ningún fragmento encontrado",strong:"fuerte",partial:"parcial",absent:"no localizado",searching:"Buscando en las fuentes…",searchError:"No fue posible consultar las fuentes ahora.",noResults:"Sin resultados. Pruebe sinónimos o quite el filtro anual.",results:"resultados consolidados",openText:"texto abierto indicado",unknownDate:"s.f.",types:["Aún no lo sé","Experimental","Observacional","Ensayo aleatorizado","Revisión sistemática","Computacional/simulación","Teórico/matemático","Cualitativo"]
  },
  "zh-CN": {
    eyebrow:"开放方法学实验室",hero:"从疑问到研究——但不把清单当作真理。",intro:"通过12个可迭代阶段组织问题、证据、模型、数据与批评。系统评估文档完整性；科学共同体评估有效性。",local:"保存在本设备",audit:"决策可审计",free:"无需付费 API",navBuild:"构建研究",navAnalyze:"分析论文",navMap:"方法地图",navSearch:"检索文献",project:"研究项目",workingTitle:"暂定标题",question:"初始疑问或问题",studyType:"研究类型",progress:"已记录进度",stage:"阶段",purpose:"目的",mainRecord:"主要记录",evidence:"证据、来源或决策",limits:"不确定性、风险或局限",readiness:"就绪标准",gate:"透明门槛：主记录≥80字符；证据/决策≥40；局限≥25；勾选全部条目。",previous:"上一步",autosave:"自动保存",reopen:"重新打开阶段",caveat:"带保留意见继续",validate:"验证并继续",lockedNext:"本阶段完成前，下一阶段保持锁定。",overrideReason:"说明保留意见（至少20字符）",recordCaveat:"记录保留意见",exportProject:"导出项目",importJson:"导入 JSON",safety:"ScientiaMap 不能替代专家指导、伦理审查、统计审查、同行评审或临床判断。",analyzeTitle:"论文分解器",analyzeIntro:"粘贴全文或加载文本文件。分析不仅查看标题，还会把正文片段映射到12个阶段。",textFile:"文本文件",articleText:"论文文本",analyzeAction:"分析内容",heuristic:"本地启发式分析。置信度表示文本匹配，而非质量、真实性或偏倚风险。",mapTitle:"方法是允许返回的网络，而非不可逆阶梯",mapIntro:"门槛用于避免跳过必要文档。意外结果可能要求返回概念、模型、预测、仪器或分析。",conceptual:"概念构建",empirical:"经验对照",publicCritique:"公开批评",returns:"允许返回并记录",mapNote:"就绪只表示最低要素已明确；不表示假设为真、设计合乎伦理或分析正确。",searchTitle:"联邦式文献发现",searchIntro:"检索 Crossref、Europe PMC 与 arXiv 元数据。范围较广但并不穷尽；各数据库覆盖和政策不同。",query:"主题、标题、作者、DOI 或关键词",yearFrom:"起始年份",yearTo:"结束年份",searchAction:"检索",paywall:"平台绝不绕过付费墙，只指向元数据与合法开放文本，并尽可能保留 DOI、来源和许可信息。",sourcesLimits:"来源与边界",sourceText:"生产架构还计划支持通过免费密钥或本地快照使用 OpenAlex，以及 PubMed/PMC、DOAJ、SciELO 和 OAI-PMH 仓储。单一来源无法代表“全部研究”。",newProject:"新建项目",confirmReset:"删除本设备保存的项目并新建吗？",ready:"已就绪",open:"编辑中",locked:"已锁定",overridden:"有保留意见",incomplete:"仍缺少文档完整性所需元素。",likelyType:"可能类型",words:"词",coverage:"覆盖",confidence:"置信度",snippets:"定位片段",none:"未定位片段",strong:"强",partial:"部分",absent:"未定位",searching:"正在检索数据源…",searchError:"目前无法查询数据源。",noResults:"未找到结果。请尝试同义词或移除年份筛选。",results:"条合并结果",openText:"标注开放全文",unknownDate:"无日期",types:["尚未确定","实验研究","观察性研究","随机试验","系统综述","计算/模拟","理论/数学","定性研究"]
  }
};

const BASE_STAGES = [
  ["Fenômeno","Fenômeno e problema","Separar o que foi observado do que apenas foi imaginado.","Descreva o fenômeno, onde ocorre, para quem importa e qual anomalia ou lacuna despertou a dúvida.",["Distingui observação de interpretação","Delimitei contexto e população","Registrei por que o problema importa"]],
  ["Pergunta","Pergunta investigável","Converter curiosidade em uma pergunta que possa receber evidência.","Formule uma pergunta específica. Indique unidade de análise, comparação, desfecho e horizonte temporal quando aplicável.",["A pergunta é específica","Pode ser contrariada por dados","Evita termos vagos ou circulares"]],
  ["Hipótese","Conhecimento prévio e hipótese","Ligar a pergunta ao que já se sabe e declarar uma resposta provisória.","Resuma o conhecimento prévio, cite explicações rivais e escreva a hipótese como uma proposição provisória, não como conclusão.",["Busquei literatura relevante","Incluí hipóteses rivais","A hipótese não foi tratada como verdade"]],
  ["Conceitos","Conceitos e definições operacionais","Traduzir palavras abstratas em operações observáveis e mensuráveis.","Defina cada conceito central e diga exatamente como será reconhecido, classificado ou medido.",["Defini os termos centrais","Indiquei medidas ou indicadores","Considerei validade e ambiguidade"]],
  ["Modelo","Modelo, idealizações e domínio","Construir uma representação simplificada sem escondê-la como realidade completa.","Declare entidades, relações, mecanismos, simplificações, condições de contorno e domínio de validade do modelo.",["Listei pressupostos","Delimitei onde o modelo vale","Registrei idealizações e omissões"]],
  ["Representação","Representação matemática ou computacional","Expressar relações com símbolos, algoritmos ou estruturas formais quando isso acrescenta precisão.","Defina variáveis, unidades, relações e parâmetros. Justifique cada forma matemática ou computacional adotada.",["Cada símbolo tem significado e unidade","A forma escolhida tem justificativa","Verifiquei consistência dimensional ou lógica"]],
  ["Predições","Consequências e predições","Deduzir o que deveria ser observado se a hipótese e o modelo forem adequados.","Escreva previsões quantitativas ou qualitativas, critérios de incompatibilidade e resultados que distinguem hipóteses rivais.",["Predições antecedem a análise","Há critério de incompatibilidade","As rivais fazem previsões distinguíveis"]],
  ["Desenho","Desenho do estudo e instrumentos","Planejar um teste capaz de responder à pergunta com riscos conhecidos.","Descreva desenho, amostragem, controles, instrumentos, protocolo, ética, potência ou suficiência informacional.",["O desenho responde à pergunta","Controles e vieses foram tratados","Ética, riscos e plano analítico foram considerados"]],
  ["Dados","Intervenção, observação e dados","Executar o protocolo preservando proveniência e qualidade dos registros.","Registre como, quando e por quem os dados foram obtidos; anote desvios, calibração, perdas e transformações.",["Preservei dados e metadados","Registrei desvios do protocolo","Mantive rastreabilidade e controle de qualidade"]],
  ["Análise","Análise e incerteza","Transformar dados em estimativas sem apagar erro, variabilidade ou decisões analíticas.","Descreva limpeza, exclusões, modelos, código, incerteza, análise de sensibilidade e alternativas razoáveis.",["Relatei incerteza, não só estimativas","Decisões analíticas são auditáveis","Testei robustez ou sensibilidade"]],
  ["Confronto","Confronto entre previsão e mundo","Interpretar resultados em relação às previsões, rivais e limitações.","Compare resultados e previsões. Diga o que foi sustentado, enfraquecido ou permaneceu indeterminado e por quê.",["Não confundi compatibilidade com prova","Considerei explicações rivais","Limitei a conclusão ao alcance dos dados"]],
  ["Comunicação","Comunicação, crítica e replicação","Tornar o trabalho compreensível, verificável, reutilizável e criticável.","Prepare relato, referências, dados/código quando possível, limitações, conflitos, licença e plano de replicação.",["O relato permite auditoria","Materiais têm licença e proveniência","Crítica, revisão e replicação são possíveis"]]
];

const STAGE_TRANSLATIONS = {
  en: [
    ["Phenomenon","Phenomenon and problem","Separate what was observed from what was only imagined.","Describe the phenomenon, its context, who it matters to, and the anomaly or gap that raised the question.",["I separated observation from interpretation","I bounded context and population","I recorded why the problem matters"]],
    ["Question","Researchable question","Turn curiosity into a question that can receive evidence.","Write a specific question. State unit of analysis, comparison, outcome, and time horizon when relevant.",["The question is specific","Data could count against it","It avoids vague or circular terms"]],
    ["Hypothesis","Prior knowledge and hypothesis","Connect the question to existing knowledge and state a provisional answer.","Summarize prior knowledge, rival explanations, and a provisional hypothesis rather than a conclusion.",["I searched relevant literature","I included rival hypotheses","I did not treat the hypothesis as true"]],
    ["Concepts","Concepts and operational definitions","Translate abstract words into observable and measurable operations.","Define each central concept and how it will be recognized, classified, or measured.",["Core terms are defined","Measures or indicators are stated","Validity and ambiguity were considered"]],
    ["Model","Model, idealizations, and domain","Build a simplified representation without disguising it as the whole reality.","State entities, relations, mechanisms, simplifications, boundary conditions, and domain of validity.",["Assumptions are listed","The valid domain is bounded","Idealizations and omissions are recorded"]],
    ["Representation","Mathematical or computational representation","Use symbols, algorithms, or formal structures when they add precision.","Define variables, units, relations, and parameters; justify each chosen form.",["Every symbol has meaning and units","The chosen form is justified","Dimensional or logical consistency was checked"]],
    ["Predictions","Consequences and predictions","Derive what should be observed if the hypothesis and model are adequate.","State predictions, incompatibility criteria, and outcomes that distinguish rivals.",["Predictions precede analysis","An incompatibility criterion exists","Rivals make distinguishable predictions"]],
    ["Design","Study and instrument design","Plan a test that can answer the question with known risks.","Describe design, sampling, controls, instruments, protocol, ethics, and informational sufficiency.",["The design answers the question","Controls and biases were addressed","Ethics, risks, and analysis were considered"]],
    ["Data","Intervention, observation, and data","Run the protocol while preserving provenance and record quality.","Record how, when, and by whom data were obtained; note deviations, calibration, losses, and transformations.",["Data and metadata are preserved","Protocol deviations are recorded","Traceability and quality control are maintained"]],
    ["Analysis","Analysis and uncertainty","Turn data into estimates without erasing error, variability, or analytical choices.","Describe cleaning, exclusions, models, code, uncertainty, sensitivity, and reasonable alternatives.",["Uncertainty is reported","Analytical choices are auditable","Robustness or sensitivity was tested"]],
    ["Confrontation","Confronting prediction with the world","Interpret results against predictions, rivals, and limitations.","Compare results with predictions. State what was supported, weakened, or remained indeterminate and why.",["Compatibility was not called proof","Rival explanations were considered","Conclusions match the data's reach"]],
    ["Communication","Communication, critique, and replication","Make the work understandable, verifiable, reusable, and criticizable.","Prepare report, references, data/code, limitations, conflicts, license, and replication plan.",["The report supports audit","Materials have license and provenance","Critique, review, and replication are possible"]]
  ],
  es: [
    ["Fenómeno","Fenómeno y problema","Separar lo observado de lo solamente imaginado.","Describa el fenómeno, su contexto, a quién importa y qué anomalía o laguna originó la duda.",["Separé observación e interpretación","Delimité contexto y población","Registré por qué importa el problema"]],
    ["Pregunta","Pregunta investigable","Convertir la curiosidad en una pregunta que pueda recibir evidencia.","Formule una pregunta específica e indique unidad de análisis, comparación, resultado y tiempo.",["La pregunta es específica","Los datos podrían contrariarla","Evita términos vagos o circulares"]],
    ["Hipótesis","Conocimiento previo e hipótesis","Vincular la pregunta con lo conocido y declarar una respuesta provisional.","Resuma antecedentes, explicaciones rivales y una hipótesis provisional.",["Busqué literatura relevante","Incluí hipótesis rivales","No traté la hipótesis como verdad"]],
    ["Conceptos","Conceptos y definiciones operacionales","Traducir palabras abstractas en operaciones observables y medibles.","Defina cada concepto y cómo será reconocido, clasificado o medido.",["Definí términos centrales","Indiqué medidas o indicadores","Consideré validez y ambigüedad"]],
    ["Modelo","Modelo, idealizaciones y dominio","Construir una representación simplificada sin confundirla con toda la realidad.","Declare entidades, relaciones, mecanismos, simplificaciones, condiciones de borde y dominio.",["Enumeré supuestos","Delimité dónde vale el modelo","Registré idealizaciones y omisiones"]],
    ["Representación","Representación matemática o computacional","Usar símbolos, algoritmos o estructuras formales cuando aporten precisión.","Defina variables, unidades, relaciones y parámetros; justifique cada forma.",["Cada símbolo tiene significado y unidad","La forma elegida está justificada","Verifiqué consistencia dimensional o lógica"]],
    ["Predicciones","Consecuencias y predicciones","Deducir qué debería observarse si la hipótesis y el modelo son adecuados.","Escriba predicciones, criterios de incompatibilidad y resultados que distingan rivales.",["Las predicciones preceden al análisis","Existe criterio de incompatibilidad","Las rivales producen predicciones distinguibles"]],
    ["Diseño","Diseño del estudio e instrumentos","Planear una prueba capaz de responder con riesgos conocidos.","Describa diseño, muestra, controles, instrumentos, protocolo, ética y suficiencia.",["El diseño responde a la pregunta","Traté controles y sesgos","Consideré ética, riesgos y análisis"]],
    ["Datos","Intervención, observación y datos","Ejecutar el protocolo preservando procedencia y calidad.","Registre cómo, cuándo y por quién se obtuvieron datos; anote desvíos, calibración y pérdidas.",["Preservé datos y metadatos","Registré desvíos del protocolo","Mantuve trazabilidad y calidad"]],
    ["Análisis","Análisis e incertidumbre","Transformar datos en estimaciones sin borrar error, variabilidad ni decisiones.","Describa limpieza, exclusiones, modelos, código, incertidumbre y sensibilidad.",["Informé incertidumbre","Las decisiones son auditables","Probé robustez o sensibilidad"]],
    ["Contraste","Contraste entre predicción y mundo","Interpretar resultados frente a predicciones, rivales y limitaciones.","Compare resultados y predicciones; diga qué fue apoyado, debilitado o quedó indeterminado.",["No confundí compatibilidad con prueba","Consideré explicaciones rivales","Limité la conclusión a los datos"]],
    ["Comunicación","Comunicación, crítica y replicación","Hacer el trabajo comprensible, verificable, reutilizable y criticable.","Prepare informe, referencias, datos/código, limitaciones, conflictos, licencia y replicación.",["El informe permite auditoría","Los materiales tienen licencia y procedencia","Crítica, revisión y replicación son posibles"]]
  ],
  "zh-CN": [
    ["现象","现象与问题","区分实际观察与纯粹想象。","描述现象、发生情境、利益相关者以及引发疑问的异常或知识空白。",["区分了观察与解释","限定了情境与研究对象","说明了问题的重要性"]],
    ["问题","可研究的问题","把好奇心转化为能够由证据回答的问题。","提出具体问题；适用时说明分析单位、比较、结局和时间范围。",["问题足够具体","数据可能反驳它","避免含糊或循环表述"]],
    ["假设","先验知识与假设","把问题连接到已有知识，并提出暂时性答案。","概述已有研究、竞争性解释，并把假设写成暂定命题。",["检索了相关文献","纳入了竞争性假设","没有把假设当作真理"]],
    ["概念","概念与操作性定义","把抽象词语转化为可观察、可测量的操作。","定义核心概念，并说明如何识别、分类或测量。",["定义了核心术语","说明了测量或指标","考虑了效度与歧义"]],
    ["模型","模型、理想化与适用域","建立简化表征，同时不把它伪装成完整现实。","声明实体、关系、机制、简化、边界条件与模型适用范围。",["列出了假定","限定了适用范围","记录了理想化与省略"]],
    ["表征","数学或计算表征","在能增加精确性时使用符号、算法或形式结构。","定义变量、单位、关系与参数，并论证每种形式。",["每个符号有含义和单位","所选形式有依据","检查了量纲或逻辑一致性"]],
    ["预测","推论与预测","推导若假设和模型合适时应观察到什么。","写出预测、不相容标准以及区分竞争性假设的结果。",["预测先于分析","存在不相容标准","竞争假设有可区分的预测"]],
    ["设计","研究与仪器设计","规划能回答问题且风险明确的检验。","描述设计、抽样、对照、仪器、方案、伦理与信息充分性。",["设计能回答问题","处理了对照与偏倚","考虑了伦理、风险与分析"]],
    ["数据","干预、观察与数据","执行方案并保留来源与记录质量。","记录数据如何、何时、由谁获得，并记录偏离、校准、缺失和转换。",["保留数据与元数据","记录了方案偏离","保持可追溯性与质量控制"]],
    ["分析","分析与不确定性","从数据获得估计，同时保留误差、变异和分析选择。","描述清理、排除、模型、代码、不确定性和敏感性分析。",["报告了不确定性","分析决策可审计","检验了稳健性或敏感性"]],
    ["对照","预测与现实的对照","依据预测、竞争解释与局限来解释结果。","比较结果与预测，说明哪些得到支持、削弱或仍不确定。",["没有把相容性称为证明","考虑了竞争性解释","结论不超出数据范围"]],
    ["传播","传播、批评与复现","使研究可理解、可验证、可复用并可批评。","准备报告、参考文献、数据/代码、局限、冲突、许可与复现计划。",["报告支持审计","材料有许可和来源","批评、评审与复现成为可能"]]
  ]
};

const KEYWORDS = {
  1:["background","context","phenomen","problem","gap","observ","introdução","fenômeno","problema","contexto","antecedentes","fenómeno","问题","现象","背景"],
  2:["research question","objective","aim","purpose","pergunta","objetivo","pregunta","propósito","研究问题","目的"],
  3:["hypoth","prior work","literature","related work","hipótese","literatura","hipótesis","假设","文献"],
  4:["definition","operational","construct","variable","outcome","definição","operacional","variável","definición","操作性","变量","结局"],
  5:["model","mechanism","assumption","boundary condition","idealization","modelo","mecanismo","pressuposto","supuesto","模型","机制","假定"],
  6:["equation","formula","algorithm","simulation","parameter","equação","fórmula","algoritmo","simulação","ecuación","方程","公式","算法","参数"],
  7:["predict","expected","preregister","a priori","previsão","predição","esperado","predicción","预测","预期","预注册"],
  8:["method","design","protocol","sample","participant","instrument","random","control","método","desenho","protocolo","amostra","diseño","muestra","方法","设计","样本","对照"],
  9:["data collection","measurement","procedure","experiment","survey","interview","coleta","medição","procedimento","experimento","encuesta","数据收集","测量","程序","实验"],
  10:["analysis","statistic","confidence interval","uncertainty","sensitivity","regression","análise","estatística","incerteza","análisis","estadística","分析","统计","置信区间"],
  11:["result","discussion","interpret","support","limitation","conclusion","resultado","discussão","interpretação","limitação","discusión","结果","讨论","解释","局限","结论"],
  12:["reference","supplement","data availability","code availability","replic","peer review","referência","disponibilidade","replicação","referencia","参考文献","数据可用性","复现"]
};

let lang = localStorage.getItem("scientiamap-lang") || "pt-BR";
if (!LANGS.includes(lang)) lang = "pt-BR";
const newProject = () => ({title:"",question:"",type:"generic",current:1,updatedAt:new Date().toISOString(),stages:Object.fromEntries(Array.from({length:12},(_,i)=>[i+1,{main:"",evidence:"",limits:"",checks:[false,false,false],status:"open",overrideReason:""}]))});
let project;
try { project = JSON.parse(localStorage.getItem("scientiamap-project-v1")) || newProject(); } catch { project = newProject(); }

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const stages = () => lang === "pt-BR" ? BASE_STAGES : STAGE_TRANSLATIONS[lang];
const tr = key => TEXT[lang][key] ?? key;
const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
const safeUrl = value => { try { const u = new URL(value); return ["http:","https:"].includes(u.protocol) ? u.href : ""; } catch { return ""; } };
const save = () => {
  project.updatedAt = new Date().toISOString();
  localStorage.setItem("scientiamap-project-v1",JSON.stringify(project));
  localStorage.setItem("scientiamap-lang",lang);
  window.dispatchEvent(new CustomEvent("scientiamap:save",{detail:{project:structuredClone(project),lang}}));
};
const statusText = status => status === "ready" ? tr("ready") : status === "override" ? tr("overridden") : tr("open");
const unlocked = id => id === 1 || Array.from({length:id-1},(_,i)=>project.stages[i+1].status !== "open").every(Boolean);

function applyLanguage() {
  document.documentElement.lang = lang;
  $$('[data-i18n]').forEach(el => el.textContent = tr(el.dataset.i18n));
  $("#new-project").textContent = tr("newProject");
  const select = $("#study-type");
  select.innerHTML = STUDY_KEYS.map((key,i)=>`<option value="${key}">${esc(TEXT[lang].types[i])}</option>`).join("");
  select.value = project.type;
  renderAll();
  window.dispatchEvent(new CustomEvent("scientiamap:language",{detail:{lang}}));
}

function bindProjectInputs() {
  $("#project-title").value = project.title;
  $("#project-question").value = project.question;
  $("#study-type").value = project.type;
  $("#project-title").oninput = e => { project.title=e.target.value; save(); renderProgress(); };
  $("#project-question").oninput = e => { project.question=e.target.value; save(); };
  $("#study-type").onchange = e => { project.type=e.target.value; save(); };
}

function renderProgress() {
  const count = Object.values(project.stages).filter(s=>s.status!=="open").length;
  $("#progress-count").textContent = `${count}/12`;
  $("#progress-bar").style.width = `${count/12*100}%`;
  $("[data-project-title]").textContent = project.title || tr("workingTitle");
}

function renderRail() {
  $("#stage-rail").innerHTML = stages().map((stage,i)=>{
    const id=i+1,status=project.stages[id].status,isOpen=unlocked(id);
    return `<button type="button" data-stage="${id}" class="${project.current===id?'selected ':''}${status}" ${isOpen?'':'disabled'}><span class="stage-number">${String(id).padStart(2,'0')}</span><span><strong>${esc(stage[0])}</strong><small>${isOpen?statusText(status):tr('locked')}</small></span><span aria-hidden="true">${!isOpen?'×':status==='ready'?'✓':status==='override'?'!':'→'}</span></button>`;
  }).join("");
  $$("#stage-rail button").forEach(button=>button.onclick=()=>chooseStage(Number(button.dataset.stage)));
}

function renderEditor() {
  const id=project.current,def=stages()[id-1],entry=project.stages[id];
  $("#stage-counter").textContent=`${id}/12`; $("#stage-title").textContent=def[1]; $("#stage-goal").textContent=def[2]; $("#stage-prompt").textContent=def[3];
  $("#stage-status").className=`status-pill ${entry.status}`; $("#stage-status").textContent=statusText(entry.status);
  $("#stage-main").value=entry.main; $("#stage-evidence").value=entry.evidence; $("#stage-limits").value=entry.limits;
  $("#stage-checks").innerHTML=def[4].map((item,index)=>`<label class="check"><input type="checkbox" data-check="${index}" ${entry.checks[index]?'checked':''}><span>${esc(item)}</span></label>`).join("");
  $$("[data-check]").forEach(box=>box.onchange=()=>{entry.checks[Number(box.dataset.check)]=box.checked;save();});
  const note=$("#override-note"); note.hidden=!entry.overrideReason; note.innerHTML=entry.overrideReason?`<strong>${esc(tr('overridden'))}:</strong> ${esc(entry.overrideReason)}`:"";
  const done=entry.status!=="open"; $("#reopen-stage").hidden=!done; $("#override-stage").hidden=done; $("#validate-stage").hidden=done;
  $("#previous-stage").disabled=id===1; $("#locked-note").hidden=id===12||done; $("#override-box").hidden=true; $("#validation").hidden=true;
}

function renderMap() {
  $("#method-map").innerHTML=stages().map((stage,i)=>{const id=i+1,kind=id<=7?'conceptual':id<=11?'empirical':'public';return `<button type="button" data-map-stage="${id}" class="${kind} ${project.stages[id].status}"><span>${String(id).padStart(2,'0')}</span><strong>${esc(stage[0])}</strong><small>${esc(stage[2])}</small></button>`}).join("");
  $$('[data-map-stage]').forEach(button=>button.onclick=()=>{showTab('build');if(unlocked(Number(button.dataset.mapStage)))chooseStage(Number(button.dataset.mapStage));});
}

function renderAll(){bindProjectInputs();renderProgress();renderRail();renderEditor();renderMap();}
function chooseStage(id){if(!unlocked(id))return;project.current=id;save();renderRail();renderEditor();}
function updateCurrent(field,value){project.stages[project.current][field]=value;save();}
function advance(){if(project.current<12)project.current++;save();renderAll();}

function validateStage(){
  const e=project.stages[project.current];
  if(e.main.trim().length<80||e.evidence.trim().length<40||e.limits.trim().length<25||!e.checks.every(Boolean)){const v=$("#validation");v.textContent=tr("incomplete");v.hidden=false;return;}
  e.status="ready";e.overrideReason="";advance();
}
function overrideStage(){const reason=$("#override-reason").value.trim();if(reason.length<20){const v=$("#validation");v.textContent=tr("incomplete");v.hidden=false;return;}const e=project.stages[project.current];e.status="override";e.overrideReason=reason;$("#override-reason").value="";advance();}

function showTab(name){
  $$('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));
  $$('.panel').forEach(p=>{const active=p.id===`panel-${name}`;p.hidden=!active;p.classList.toggle('active',active);});
}

function inferType(text){const s=text.toLocaleLowerCase();if(/systematic review|meta-analysis|revis[aã]o sistem[aá]tica|revisi[oó]n sistem[aá]tica|系统综述|荟萃分析/.test(s))return"systematic";if(/randomi[sz]ed|aleatori[sz]ad|随机(对照)?试验/.test(s))return"randomized";if(/qualitative|focus group|thematic analysis|qualitativ|定性研究|主题分析/.test(s))return"qualitative";if(/cohort|case-control|cross-sectional|observational|coorte|transversal|observacional|队列|病例对照|横断面/.test(s))return"observational";if(/theorem|lemma|mathematical proof|teorema|demonstra[cç][aã]o|定理|引理|数学证明/.test(s))return"theoretical";if(/simulation|computational model|machine learning|simula[cç][aã]o|modelo computacional|模拟|机器学习/.test(s))return"computational";if(/experiment|laboratory|intervention|experimento|实验|干预/.test(s))return"experimental";return"generic";}
function analyzeText(text){
  const normalized=text.normalize("NFKC"),lower=normalized.toLocaleLowerCase();
  const paragraphs=normalized.split(/\n\s*\n|(?<=[.!?。！？])\s+(?=[A-ZÁÉÍÓÚÀÂÊÔÃÕÜÑ\u4e00-\u9fff])/u).map(x=>x.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim().slice(0,360)).filter(x=>x.length>=35);
  const results=Object.entries(KEYWORDS).map(([id,terms])=>{const matched=terms.filter(term=>lower.includes(term.toLocaleLowerCase()));const snippets=paragraphs.filter(p=>terms.some(term=>p.toLocaleLowerCase().includes(term.toLocaleLowerCase()))).slice(0,2);const raw=matched.length?18+matched.length*9+Math.min(24,snippets.length*6):0;const confidence=Math.min(96,raw);return{id:Number(id),confidence,status:confidence>=60?'strong':confidence>=30?'partial':'absent',snippets};});
  return{type:inferType(normalized),words:normalized.trim()?normalized.trim().split(/\s+/u).length:0,results};
}
function renderAnalysis(result){
  const typeIndex=STUDY_KEYS.indexOf(result.type),covered=result.results.filter(r=>r.status!=='absent').length;
  $("#analysis-summary").innerHTML=`<div><span>${esc(tr('likelyType'))}</span><strong>${esc(TEXT[lang].types[typeIndex])}</strong></div><div><span>${esc(tr('words'))}</span><strong>${result.words.toLocaleString(lang)}</strong></div><div><span>${esc(tr('coverage'))}</span><strong>${covered}/12</strong></div>`;
  $("#coverage-list").innerHTML=result.results.map(r=>{const def=stages()[r.id-1];return `<article class="coverage-row"><div class="coverage-stage"><span>${String(r.id).padStart(2,'0')}</span><div><strong>${esc(def[1])}</strong><small class="${r.status}">${esc(tr(r.status))}</small></div></div><div class="confidence"><span style="width:${r.confidence}%"></span><small>${r.confidence}% ${esc(tr('confidence'))}</small></div><div class="snippets"><strong>${esc(tr('snippets'))}</strong>${r.snippets.length?r.snippets.map(s=>`<blockquote>${esc(s)}</blockquote>`).join(''):`<p>${esc(tr('none'))}</p>`}</div></article>`}).join("");
  $("#analysis-results").hidden=false;
}

function projectMarkdown(){let out=`# ${project.title||'ScientiaMap'}\n\n**${tr('question')}:** ${project.question}\n\n**${tr('studyType')}:** ${TEXT[lang].types[STUDY_KEYS.indexOf(project.type)]}\n\n`;stages().forEach((def,i)=>{const e=project.stages[i+1];out+=`## ${i+1}. ${def[1]}\n\n${e.main}\n\n**${tr('evidence')}:** ${e.evidence}\n\n**${tr('limits')}:** ${e.limits}\n\n${def[4].map((x,j)=>`- [${e.checks[j]?'x':' '}] ${x}`).join('\n')}\n\n`;if(e.overrideReason)out+=`> ${tr('overridden')}: ${e.overrideReason}\n\n`;});return out+`---\n${tr('safety')}\n`;}
function htmlDoc(){return`<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><title>${esc(project.title||'ScientiaMap')}</title><style>body{font:16px/1.6 system-ui;max-width:900px;margin:40px auto;padding:0 24px;color:#17231e}h1,h2{color:#123d31}section{border-top:1px solid #d7ddd9;padding:20px 0}.warn{padding:16px;background:#fff4dc;border-left:4px solid #b77416}</style></head><body><h1>${esc(project.title||'ScientiaMap')}</h1><p><strong>${esc(tr('question'))}:</strong> ${esc(project.question)}</p>${stages().map((def,i)=>{const e=project.stages[i+1];return`<section><h2>${i+1}. ${esc(def[1])}</h2><p>${esc(e.main)}</p><p><strong>${esc(tr('evidence'))}:</strong> ${esc(e.evidence)}</p><p><strong>${esc(tr('limits'))}:</strong> ${esc(e.limits)}</p><ul>${def[4].map((x,j)=>`<li>${e.checks[j]?'☑':'☐'} ${esc(x)}</li>`).join('')}</ul>${e.overrideReason?`<p class="warn">${esc(tr('overridden'))}: ${esc(e.overrideReason)}</p>`:''}</section>`}).join('')}<p class="warn">${esc(tr('safety'))}</p></body></html>`;}
function texDoc(){const tex=s=>String(s||'').replace(/([#$%&_{}])/g,'\\$1').replace(/~/g,'\\textasciitilde{}').replace(/\^/g,'\\textasciicircum{}');return`\\documentclass[11pt]{article}\n\\usepackage[utf8]{inputenc}\n\\usepackage{geometry}\n\\geometry{margin=2.5cm}\n\\title{${tex(project.title||'ScientiaMap')}}\n\\begin{document}\n\\maketitle\n${stages().map((d,i)=>{const e=project.stages[i+1];return`\\section{${i+1}. ${tex(d[1])}}\n${tex(e.main)}\n\n\\textbf{${tex(tr('evidence'))}:} ${tex(e.evidence)}\n\n\\textbf{${tex(tr('limits'))}:} ${tex(e.limits)}\n`}).join('\n')}\\end{document}`;}
function csvDoc(){const q=x=>`"${String(x||'').replace(/"/g,'""')}"`;return'\uFEFF'+[[tr('stage'),tr('mainRecord'),tr('evidence'),tr('limits'),'status'],...stages().map((d,i)=>{const e=project.stages[i+1];return[`${i+1}. ${d[1]}`,e.main,e.evidence,e.limits,e.status]})].map(row=>row.map(q).join(';')).join('\r\n');}
function download(name,body,type){const url=URL.createObjectURL(new Blob([body],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function exportProject(kind){const base=(project.title||'scientiamap-projeto').toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu,'-').replace(/^-|-$/g,'').slice(0,55)||'scientiamap-projeto';if(kind==='md')download(`${base}.md`,projectMarkdown(),'text/markdown;charset=utf-8');if(kind==='html')download(`${base}.html`,htmlDoc(),'text/html;charset=utf-8');if(kind==='doc')download(`${base}.doc`,htmlDoc(),'application/msword');if(kind==='csv')download(`${base}.csv`,csvDoc(),'text/csv;charset=utf-8');if(kind==='tex')download(`${base}.tex`,texDoc(),'application/x-tex;charset=utf-8');if(kind==='json')download(`${base}.json`,JSON.stringify({schema:'scientiamap-project/v1',lang,project},null,2),'application/json;charset=utf-8');if(kind==='pdf'){const w=window.open('','_blank');if(w){w.document.write(htmlDoc());w.document.close();setTimeout(()=>w.print(),300);}}}

async function searchLiterature(event){
  event.preventDefault();const query=$("#search-query").value.trim();if(query.length<2)return;const msg=$("#search-message"),button=$("#search-button");msg.textContent=tr('searching');msg.hidden=false;button.disabled=true;$("#literature-list").innerHTML='';$("#result-count").hidden=true;
  try{const p=new URLSearchParams({q:query});if($("#year-from").value)p.set('from',$("#year-from").value);if($("#year-to").value)p.set('to',$("#year-to").value);const response=await fetch(`/api/search?${p}`);if(!response.ok)throw new Error('search');const data=await response.json();renderSearch(data.results||[]);msg.hidden=true;}catch{msg.textContent=tr('searchError');}
  finally{button.disabled=false;}
}
function renderSearch(results){const count=$("#result-count");if(!results.length){count.hidden=true;$("#literature-list").innerHTML=`<p class="empty">${esc(tr('noResults'))}</p>`;return;}count.innerHTML=`<strong>${results.length}</strong> ${esc(tr('results'))}`;count.hidden=false;$("#literature-list").innerHTML=results.map(r=>{const url=safeUrl(r.url),doi=String(r.doi||'').replace(/^https?:\/\/(dx\.)?doi\.org\//i,'');return`<article><div class="source-tag">${esc(r.source)}${r.openAccess?` · ${esc(tr('openText'))}`:''}</div><h3>${url?`<a href="${esc(url)}" target="_blank" rel="noreferrer">${esc(r.title)}</a>`:esc(r.title)}</h3><p>${esc((r.authors||[]).join(', ')||'—')}</p><div class="metadata"><span>${esc(r.year||tr('unknownDate'))}</span>${r.venue?`<span>${esc(r.venue)}</span>`:''}${r.type?`<span>${esc(r.type)}</span>`:''}${doi?`<a href="https://doi.org/${encodeURIComponent(doi)}" target="_blank" rel="noreferrer">DOI ${esc(doi)}</a>`:''}</div></article>`}).join('');}

$("#language").value=lang;$("#language").onchange=e=>{lang=e.target.value;applyLanguage();save();};
$$('.tabs button').forEach(button=>button.onclick=()=>showTab(button.dataset.tab));
$("#stage-main").oninput=e=>updateCurrent('main',e.target.value);$("#stage-evidence").oninput=e=>updateCurrent('evidence',e.target.value);$("#stage-limits").oninput=e=>updateCurrent('limits',e.target.value);
$("#previous-stage").onclick=()=>chooseStage(Math.max(1,project.current-1));$("#validate-stage").onclick=validateStage;$("#override-stage").onclick=()=>{$("#override-box").hidden=false;$("#override-reason").focus();};$("#cancel-override").onclick=()=>{$("#override-box").hidden=true;};$("#confirm-override").onclick=overrideStage;$("#reopen-stage").onclick=()=>{project.stages[project.current].status='open';save();renderAll();};
$("#new-project").onclick=()=>{if(confirm(tr('confirmReset'))){project=newProject();save();renderAll();}};
$$('[data-export]').forEach(button=>button.onclick=()=>exportProject(button.dataset.export));
$("#import-project").onchange=async e=>{const file=e.target.files[0];if(!file)return;try{const data=JSON.parse(await file.text()),incoming=data.project||data;if(!incoming.stages||!incoming.current)throw new Error('schema');project=incoming;if(data.lang&&LANGS.includes(data.lang))lang=data.lang;applyLanguage();save();}catch{alert(tr('incomplete'));}e.target.value='';};
$("#article-file").onchange=async e=>{const file=e.target.files[0];if(file){$("#article-text").value=await file.text();$("#analysis-results").hidden=true;}};
$("#analyze-button").onclick=()=>{const text=$("#article-text").value;if(text.trim().length<80){alert(tr('incomplete'));return;}renderAnalysis(analyzeText(text));};
$("#search-form").onsubmit=searchLiterature;
window.ScientiaMapApp={
  getProject:()=>structuredClone(project),
  getLang:()=>lang,
  loadProject:(next,nextLang)=>{
    project=structuredClone(next||newProject());
    if(nextLang&&LANGS.includes(nextLang))lang=nextLang;
    $("#language").value=lang;
    applyLanguage();
    save();
  },
  createEmptyProject:()=>newProject(),
  renderAll,
  renderAnalysis,
  showTab,
  translate:tr
};
applyLanguage();
