"use strict";

(() => {
  const App = window.ScientiaMapApp;
  if (!App) return;

  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
  const state = {
    ready: false,
    loading: false,
    syncing: false,
    pendingProject: null,
    pendingLang: null,
    syncTimer: null,
    id: null,
    version: null,
    conflict: null,
    capabilities: {}
  };

  const COPY = {
    "pt-BR": {
      history: "Histórico", project: "Projeto ativo", connecting: "Conectando ao banco local…",
      online: version => `Banco local sincronizado · versão ${version}`,
      saving: "Salvando no banco local…", offline: "Servidor local indisponível; cópia preservada no navegador.",
      conflict: "Conflito de versão: sua edição foi preservada.", sync: "Sincronizar", backup: "Backup SQLite",
      noProjects: "Nenhum projeto", untitled: "Projeto sem título", newReason: "novo-projeto",
      importError: "Não foi possível importar este JSON.", analyzeError: "Não foi possível extrair ou analisar este arquivo.",
      exportError: "Não foi possível gerar este formato.", optional: "Disponível após executar o instalador completo.",
      restore: "Restaurar", restoreConfirm: version => `Restaurar a versão ${version}? O estado atual será preservado no histórico.`,
      versions: count => `${count} versões`, events: count => `${count} eventos`, current: "Versão atual",
      emptyHistory: "Ainda não há registros.", restored: "Versão restaurada como uma nova revisão.",
      extracted: warnings => warnings ? `Arquivo extraído com ${warnings} aviso(s).` : "Arquivo extraído e analisado.",
      copied: "Sua edição foi preservada como um novo projeto."
    },
    en: {
      history: "History", project: "Active project", connecting: "Connecting to the local database…",
      online: version => `Local database synchronized · version ${version}`,
      saving: "Saving to the local database…", offline: "Local server unavailable; browser copy preserved.",
      conflict: "Version conflict: your edit was preserved.", sync: "Sync now", backup: "SQLite backup",
      noProjects: "No projects", untitled: "Untitled project", newReason: "new-project",
      importError: "This JSON could not be imported.", analyzeError: "This file could not be extracted or analyzed.",
      exportError: "This format could not be generated.", optional: "Available after running the full installer.",
      restore: "Restore", restoreConfirm: version => `Restore version ${version}? The current state will remain in history.`,
      versions: count => `${count} versions`, events: count => `${count} events`, current: "Current version",
      emptyHistory: "No records yet.", restored: "Version restored as a new revision.",
      extracted: warnings => warnings ? `File extracted with ${warnings} warning(s).` : "File extracted and analyzed.",
      copied: "Your edit was preserved as a new project."
    },
    es: {
      history: "Historial", project: "Proyecto activo", connecting: "Conectando con la base local…",
      online: version => `Base local sincronizada · versión ${version}`,
      saving: "Guardando en la base local…", offline: "Servidor local no disponible; copia conservada en el navegador.",
      conflict: "Conflicto de versión: su edición fue conservada.", sync: "Sincronizar", backup: "Copia SQLite",
      noProjects: "Sin proyectos", untitled: "Proyecto sin título", newReason: "nuevo-proyecto",
      importError: "No fue posible importar este JSON.", analyzeError: "No fue posible extraer o analizar este archivo.",
      exportError: "No fue posible generar este formato.", optional: "Disponible después de ejecutar el instalador completo.",
      restore: "Restaurar", restoreConfirm: version => `¿Restaurar la versión ${version}? El estado actual permanecerá en el historial.`,
      versions: count => `${count} versiones`, events: count => `${count} eventos`, current: "Versión actual",
      emptyHistory: "Todavía no hay registros.", restored: "Versión restaurada como una nueva revisión.",
      extracted: warnings => warnings ? `Archivo extraído con ${warnings} advertencia(s).` : "Archivo extraído y analizado.",
      copied: "Su edición fue conservada como un proyecto nuevo."
    },
    "zh-CN": {
      history: "历史", project: "当前项目", connecting: "正在连接本地数据库…",
      online: version => `本地数据库已同步 · 版本 ${version}`,
      saving: "正在保存到本地数据库…", offline: "本地服务器不可用；浏览器副本已保留。",
      conflict: "版本冲突：您的编辑已保留。", sync: "同步", backup: "SQLite 备份",
      noProjects: "没有项目", untitled: "未命名项目", newReason: "new-project",
      importError: "无法导入此 JSON。", analyzeError: "无法提取或分析此文件。",
      exportError: "无法生成此格式。", optional: "运行完整安装程序后可用。",
      restore: "恢复", restoreConfirm: version => `恢复版本 ${version}？当前状态将保留在历史记录中。`,
      versions: count => `${count} 个版本`, events: count => `${count} 个事件`, current: "当前版本",
      emptyHistory: "尚无记录。", restored: "旧版本已恢复为新修订。",
      extracted: warnings => warnings ? `文件已提取，有 ${warnings} 条警告。` : "文件已提取并分析。",
      copied: "您的编辑已另存为新项目。"
    }
  };

  const words = () => COPY[App.getLang()] || COPY["pt-BR"];

  class ApiError extends Error {
    constructor(status, data) {
      super(data?.message || `HTTP ${status}`);
      this.status = status;
      this.data = data || {};
    }
  }

  async function api(path, options = {}) {
    const request = {...options, headers: {...(options.headers || {})}};
    if (request.body && typeof request.body !== "string") {
      request.headers["Content-Type"] = "application/json";
      request.body = JSON.stringify(request.body);
    }
    const response = await fetch(path, request);
    const type = response.headers.get("Content-Type") || "";
    const data = type.includes("application/json") ? await response.json() : await response.text();
    if (!response.ok) throw new ApiError(response.status, data);
    return data;
  }

  function status(message, kind = "") {
    const node = $("#api-status");
    node.textContent = message;
    node.className = `connection-status ${kind}`.trim();
  }

  function hasContent(project) {
    if (project.title?.trim() || project.question?.trim()) return true;
    return Object.values(project.stages || {}).some(stage => stage.main?.trim() || stage.evidence?.trim() || stage.limits?.trim());
  }

  function applyLabels() {
    const t = words();
    $("#history-tab").textContent = t.history;
    $(".project-switcher > label").textContent = t.project;
    $("#sync-now").textContent = t.sync;
    $("#download-backup").textContent = t.backup;
    if (state.ready) status(t.online(state.version), "online");
    else status(t.connecting);
    applyCapabilities();
  }

  function applyCapabilities() {
    const t = words();
    const requirements = {docx: "docx", xlsx: "xlsx", pdf: "pdfWrite"};
    Object.entries(requirements).forEach(([format, capability]) => {
      const button = $(`[data-export="${format}"]`);
      if (!button) return;
      const available = state.capabilities[capability] !== false;
      button.disabled = !available;
      button.title = available ? "" : t.optional;
    });
  }

  async function refreshProjectPicker() {
    const data = await api("/api/projects");
    const picker = $("#project-picker");
    const current = state.id;
    picker.innerHTML = data.projects.length
      ? data.projects.map(item => `<option value="${esc(item.id)}">${esc(item.title || words().untitled)} · v${item.version}</option>`).join("")
      : `<option value="">${esc(words().noProjects)}</option>`;
    if (current && data.projects.some(item => item.id === current)) picker.value = current;
    return data.projects;
  }

  function loadEnvelope(envelope) {
    state.loading = true;
    state.id = envelope.id;
    state.version = envelope.version;
    state.conflict = null;
    state.pendingProject = null;
    localStorage.setItem("scientiamap-project-id", envelope.id);
    $("#conflict-actions").hidden = true;
    try { App.loadProject(envelope.project, envelope.lang); }
    finally { state.loading = false; }
    status(words().online(state.version), "online");
  }

  async function loadProject(id) {
    loadEnvelope(await api(`/api/projects/${encodeURIComponent(id)}`));
    await refreshProjectPicker();
    if (!$("#panel-history").hidden) await loadHistory();
  }

  async function createProject(project, sourceSchema = "scientiamap-project/v2", reason = "project-created") {
    const envelope = await api("/api/projects", {
      method: "POST",
      body: {project, lang: App.getLang(), sourceSchema, reason}
    });
    loadEnvelope(envelope);
    await refreshProjectPicker();
    return envelope;
  }

  function scheduleSync(project, lang) {
    if (!state.ready || state.loading || !state.id) return;
    state.pendingProject = structuredClone(project);
    state.pendingLang = lang;
    clearTimeout(state.syncTimer);
    state.syncTimer = setTimeout(flushSync, 950);
  }

  async function flushSync() {
    clearTimeout(state.syncTimer);
    if (state.syncing || !state.pendingProject || !state.id) return;
    state.syncing = true;
    try {
      while (state.pendingProject) {
        const snapshot = state.pendingProject;
        const lang = state.pendingLang || App.getLang();
        state.pendingProject = null;
        status(words().saving);
        try {
          const updated = await api(`/api/projects/${encodeURIComponent(state.id)}`, {
            method: "PUT",
            body: {project: snapshot, lang, expectedVersion: state.version, reason: "browser-autosave"}
          });
          state.version = updated.version;
          status(words().online(state.version), "online");
        } catch (error) {
          if (error instanceof ApiError && error.status === 409) {
            handleConflict(error.data.current, snapshot);
            break;
          }
          state.pendingProject = snapshot;
          status(words().offline, "error");
          break;
        }
      }
      await refreshProjectPicker().catch(() => {});
      if (!$("#panel-history").hidden) await loadHistory().catch(() => {});
    } finally {
      state.syncing = false;
      if (state.pendingProject && !state.conflict) state.syncTimer = setTimeout(flushSync, 1600);
    }
  }

  async function settleSync() {
    while (state.syncing) await new Promise(resolve => setTimeout(resolve, 40));
    await flushSync();
    while (state.syncing) await new Promise(resolve => setTimeout(resolve, 40));
    if (state.conflict) throw new Error(words().conflict);
    if (state.pendingProject) throw new Error(words().offline);
  }

  function handleConflict(server, local) {
    state.conflict = {server, local: structuredClone(local)};
    state.pendingProject = null;
    $("#conflict-actions").hidden = false;
    status(words().conflict, "conflict");
  }

  function analysisForBrowser(result) {
    return {
      type: result.studyType,
      words: result.wordCount,
      results: result.stages.map(stage => ({
        id: stage.stage,
        confidence: stage.confidence,
        status: stage.status,
        snippets: stage.evidenceSpans.map(span => span.snippet)
      }))
    };
  }

  function bytesToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let start = 0; start < bytes.length; start += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(start, start + 0x8000));
    }
    return btoa(binary);
  }

  function filenameFromDisposition(value, fallback) {
    const extended = /filename\*=UTF-8''([^;]+)/i.exec(value || "");
    if (extended) {
      try { return decodeURIComponent(extended[1]); } catch { return fallback; }
    }
    return /filename="([^"]+)"/i.exec(value || "")?.[1] || fallback;
  }

  async function downloadExport(format) {
    if (!state.ready || !state.id) return;
    try {
      await settleSync();
      const response = await fetch(`/api/projects/${encodeURIComponent(state.id)}/export?format=${encodeURIComponent(format)}`);
      if (!response.ok) {
        const payload = await response.json().catch(() => ({}));
        throw new ApiError(response.status, payload);
      }
      const blob = await response.blob();
      const name = filenameFromDisposition(response.headers.get("Content-Disposition"), `scientiamap.${format}`);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = name;
      anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 1500);
    } catch (error) {
      alert(`${words().exportError}\n${error.message || ""}`.trim());
    }
  }

  const locale = () => App.getLang() === "zh-CN" ? "zh-CN" : App.getLang();
  const dateText = value => {
    try { return new Intl.DateTimeFormat(locale(), {dateStyle: "medium", timeStyle: "short"}).format(new Date(value)); }
    catch { return String(value || ""); }
  };

  async function loadHistory() {
    if (!state.id) return;
    const [versionData, auditData] = await Promise.all([
      api(`/api/projects/${encodeURIComponent(state.id)}/versions?limit=100`),
      api(`/api/projects/${encodeURIComponent(state.id)}/audit?limit=200`)
    ]);
    const versions = versionData.versions || [];
    const events = auditData.events || [];
    $("#history-summary").innerHTML = `
      <div><span>${esc(words().current)}</span><strong>v${state.version}</strong></div>
      <div><span>Snapshots</span><strong>${esc(words().versions(versions.length))}</strong></div>
      <div><span>Audit log</span><strong>${esc(words().events(events.length))}</strong></div>`;
    $("#versions-list").innerHTML = versions.length ? versions.map(item => {
      const created = item.created_at || item.createdAt;
      const restore = item.version === state.version ? "" : `<button class="button ghost" type="button" data-restore-version="${item.version}">${esc(words().restore)}</button>`;
      return `<article class="history-card"><header><div><h4>v${item.version} · ${esc(item.reason)}</h4><time datetime="${esc(created)}">${esc(dateText(created))}</time></div>${restore}</header><small>${esc(item.actor || "local-user")}</small></article>`;
    }).join("") : `<p class="history-empty">${esc(words().emptyHistory)}</p>`;
    $("#audit-list").innerHTML = events.length ? events.map(item => `
      <article class="history-card"><header><div><h4>v${item.version} · ${esc(item.summary)}</h4><time datetime="${esc(item.createdAt)}">${esc(dateText(item.createdAt))}</time></div><small>${esc(item.eventType)}</small></header>
      <p>${esc(JSON.stringify(item.details || {}))}</p></article>`).join("") : `<p class="history-empty">${esc(words().emptyHistory)}</p>`;
    $$('[data-restore-version]').forEach(button => button.onclick = () => restoreVersion(Number(button.dataset.restoreVersion)));
  }

  async function restoreVersion(targetVersion) {
    if (!confirm(words().restoreConfirm(targetVersion))) return;
    try {
      await settleSync();
      const restored = await api(`/api/projects/${encodeURIComponent(state.id)}/restore`, {
        method: "POST", body: {targetVersion, expectedVersion: state.version}
      });
      loadEnvelope(restored);
      await refreshProjectPicker();
      await loadHistory();
      status(words().restored, "online");
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) return handleConflict(error.data.current, App.getProject());
      status(words().offline, "error");
    }
  }

  function bindInterface() {
    window.addEventListener("scientiamap:save", event => scheduleSync(event.detail.project, event.detail.lang));
    window.addEventListener("scientiamap:language", () => {
      applyLabels();
      if (!$("#panel-history").hidden) loadHistory().catch(() => {});
    });

    $("#project-picker").onchange = async event => {
      if (!event.target.value || event.target.value === state.id) return;
      try { await settleSync(); await loadProject(event.target.value); }
      catch { event.target.value = state.id || ""; status(words().offline, "error"); }
    };
    $("#sync-now").onclick = () => {
      state.pendingProject = App.getProject();
      state.pendingLang = App.getLang();
      flushSync();
    };
    $("#new-project").onclick = async () => {
      try { await settleSync(); await createProject(App.createEmptyProject(), "scientiamap-project/v2", words().newReason); }
      catch { status(words().offline, "error"); }
    };
    $("#use-server-version").onclick = () => {
      if (!state.conflict) return;
      loadEnvelope(state.conflict.server);
      refreshProjectPicker().catch(() => {});
    };
    $("#save-conflict-copy").onclick = async () => {
      if (!state.conflict) return;
      const local = state.conflict.local;
      try {
        await createProject(local, "scientiamap-project/v2-conflict-copy", "conflict-copy");
        status(words().copied, "online");
      } catch { status(words().offline, "error"); }
    };

    $$('.tabs button').forEach(button => button.addEventListener("click", () => {
      if (button.dataset.tab === "history") loadHistory().catch(() => status(words().offline, "error"));
    }));
    $$('[data-export]').forEach(button => button.onclick = () => downloadExport(button.dataset.export));

    $("#import-project").onchange = async event => {
      const file = event.target.files[0];
      if (!file) return;
      try {
        await settleSync();
        const payload = JSON.parse(await file.text());
        const created = await api("/api/projects/import", {method: "POST", body: {payload, lang: payload.lang || App.getLang()}});
        loadEnvelope(created);
        await refreshProjectPicker();
      } catch (error) { alert(`${words().importError}\n${error.message || ""}`.trim()); }
      event.target.value = "";
    };

    $("#article-file").onchange = async event => {
      const file = event.target.files[0];
      if (!file) return;
      const button = $("#analyze-button");
      button.disabled = true;
      try {
        const result = await api("/api/documents/extract", {
          method: "POST",
          body: {
            filename: file.name,
            mediaType: file.type || "application/octet-stream",
            dataBase64: bytesToBase64(await file.arrayBuffer()),
            projectId: state.id,
            lang: App.getLang(),
            analyze: true
          }
        });
        $("#article-text").value = result.text || "";
        if (result.analysis) App.renderAnalysis(analysisForBrowser(result.analysis));
        status(words().extracted((result.warnings || []).length), "online");
      } catch (error) { alert(`${words().analyzeError}\n${error.message || ""}`.trim()); }
      finally { button.disabled = false; event.target.value = ""; }
    };

    $("#analyze-button").onclick = async () => {
      const text = $("#article-text").value.trim();
      if (text.length < 30) return alert(App.translate("incomplete"));
      const button = $("#analyze-button");
      button.disabled = true;
      try {
        const result = await api("/api/analyze", {method: "POST", body: {text, lang: App.getLang()}});
        App.renderAnalysis(analysisForBrowser(result));
      } catch (error) { alert(`${words().analyzeError}\n${error.message || ""}`.trim()); }
      finally { button.disabled = false; }
    };
  }

  async function initialize() {
    applyLabels();
    bindInterface();
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/service-worker.js").catch(() => {});
    try {
      const health = await api("/api/health");
      state.capabilities = health.capabilities || {};
      applyCapabilities();
      const projects = await refreshProjectPicker();
      const remembered = localStorage.getItem("scientiamap-project-id");
      const selected = projects.find(item => item.id === remembered) || projects[0];
      if (selected) await loadProject(selected.id);
      else {
        const legacy = App.getProject();
        try {
          await createProject(legacy, hasContent(legacy) ? "scientiamap-project/v1-migrated" : "scientiamap-project/v2", hasContent(legacy) ? "browser-v0.1-migration" : "first-project");
        } catch {
          await createProject(App.createEmptyProject(), "scientiamap-project/v2", "first-project");
        }
      }
      state.ready = true;
      status(words().online(state.version), "online");
    } catch (error) {
      state.ready = false;
      status(words().offline, "error");
    }
  }

  initialize();
})();
